// StudySnap Frontend Logic & Quiz Mode
document.addEventListener('DOMContentLoaded', () => {
    // DOM Elements - Upload & General
    const dropZone = document.getElementById('dropZone');
    const fileInput = document.getElementById('fileInput');
    const uploadContent = dropZone.querySelector('.upload-content');
    const fileInfo = document.getElementById('fileInfo');
    const fileNameSpan = document.getElementById('fileName');
    const fileSizeSpan = document.getElementById('fileSize');
    const removeFileBtn = document.getElementById('removeFileBtn');
    const submitBtn = document.getElementById('submitBtn');
    const uploadQuizBtn = document.getElementById('uploadQuizBtn');

    const uploadSection = document.getElementById('uploadSection');
    const loadingSection = document.getElementById('loadingSection');
    const loadingTitle = document.getElementById('loadingTitle');
    const loadingStatus = document.getElementById('loadingStatus');
    const errorMessage = document.getElementById('errorMessage');
    const errorText = document.getElementById('errorText');
    const dismissErrorBtn = document.getElementById('dismissErrorBtn');

    // DOM Elements - Summaries Results
    const resultsSection = document.getElementById('resultsSection');
    const resultDocName = document.getElementById('resultDocName');
    const newUploadBtn = document.getElementById('newUploadBtn');
    const resultsQuizBtn = document.getElementById('resultsQuizBtn');
    const summaryQuizCtaBtn = document.getElementById('summaryQuizCtaBtn');
    const modeButtons = document.querySelectorAll('.mode-btn');
    const activeModeBadge = document.getElementById('activeModeBadge');
    const summaryContent = document.getElementById('summaryContent');
    const copyBtn = document.getElementById('copyBtn');

    // DOM Elements - Quiz Mode
    const quizSection = document.getElementById('quizSection');
    const quizDocName = document.getElementById('quizDocName');
    const quizQuestionCounter = document.getElementById('quizQuestionCounter');
    const quizScoreCounter = document.getElementById('quizScoreCounter');
    const timerCircle = document.getElementById('timerCircle');
    const timerText = document.getElementById('timerText');
    const quizTimerWrapper = document.getElementById('quizTimerWrapper');
    const exitQuizBtn = document.getElementById('exitQuizBtn');
    const quizProgressBarFill = document.getElementById('quizProgressBarFill');
    const quizActiveCard = document.getElementById('quizActiveCard');
    const qTag = document.getElementById('qTag');
    const quizQuestionText = document.getElementById('quizQuestionText');
    const quizOptionsContainer = document.getElementById('quizOptionsContainer');
    const quizExplanationBox = document.getElementById('quizExplanationBox');
    const explanationIcon = document.getElementById('explanationIcon');
    const explanationTitle = document.getElementById('explanationTitle');
    const quizExplanationText = document.getElementById('quizExplanationText');
    const nextQuestionBtn = document.getElementById('nextQuestionBtn');
    const nextBtnText = document.getElementById('nextBtnText');

    // DOM Elements - Quiz Completed Card
    const quizCompletedCard = document.getElementById('quizCompletedCard');
    const finalScoreVal = document.getElementById('finalScoreVal');
    const finalTotalVal = document.getElementById('finalTotalVal');
    const finalResultTitle = document.getElementById('finalResultTitle');
    const finalResultMsg = document.getElementById('finalResultMsg');
    const statAccuracy = document.getElementById('statAccuracy');
    const statCorrect = document.getElementById('statCorrect');
    const statTotalQuestions = document.getElementById('statTotalQuestions');
    const statDifficulty = document.getElementById('statDifficulty');
    const quizDifficultyBadge = document.getElementById('quizDifficultyBadge');
    const retakeQuizBtn = document.getElementById('retakeQuizBtn');
    const changeQuizSettingsBtn = document.getElementById('changeQuizSettingsBtn');
    const backToSummariesBtn = document.getElementById('backToSummariesBtn');
    const quizNewUploadBtn = document.getElementById('quizNewUploadBtn');

    // DOM Elements - Quiz Configuration / Decision Modal
    const quizConfigModal = document.getElementById('quizConfigModal');
    const closeQuizModalBtn = document.getElementById('closeQuizModalBtn');
    const cancelQuizModalBtn = document.getElementById('cancelQuizModalBtn');
    const startCustomQuizBtn = document.getElementById('startCustomQuizBtn');
    const startQuizBtnText = document.getElementById('startQuizBtnText');
    const quizTargetFileName = document.getElementById('quizTargetFileName');
    const quizPillBtns = document.querySelectorAll('.quiz-pill-btn');
    const diffCardBtns = document.querySelectorAll('.diff-card-btn');

    // DOM Elements - Phase 3: Progress Dashboard
    const myProgressBtn = document.getElementById('myProgressBtn');
    const quizViewProgressBtn = document.getElementById('quizViewProgressBtn');
    const progressSection = document.getElementById('progressSection');
    const backFromProgressBtn = document.getElementById('backFromProgressBtn');
    const progressQuickQuizBtn = document.getElementById('progressQuickQuizBtn');
    const gamerRankBanner = document.getElementById('gamerRankBanner');
    const rankBadgeOrb = document.getElementById('rankBadgeOrb');
    const rankBadgeEmoji = document.getElementById('rankBadgeEmoji');
    const rankTierPill = document.getElementById('rankTierPill');
    const rankTitle = document.getElementById('rankTitle');
    const rankDesc = document.getElementById('rankDesc');
    const rankAvgScoreDisplay = document.getElementById('rankAvgScoreDisplay');
    const nextRankLabel = document.getElementById('nextRankLabel');
    const rankProgressBar = document.getElementById('rankProgressBar');
    const rankProgressFill = document.getElementById('rankProgressFill');
    const tierStepBeginner = document.getElementById('tierStepBeginner');
    const tierStepLearner = document.getElementById('tierStepLearner');
    const tierStepScholar = document.getElementById('tierStepScholar');
    const tierStepMaster = document.getElementById('tierStepMaster');
    const tierStepImpossible = document.getElementById('tierStepImpossible');

    const statCardTotalQuizzes = document.getElementById('statCardTotalQuizzes');
    const statCardAverageScore = document.getElementById('statCardAverageScore');
    const statCardBestScore = document.getElementById('statCardBestScore');
    const statCardBestScoreSub = document.getElementById('statCardBestScoreSub');
    const statCardTotalQuestions = document.getElementById('statCardTotalQuestions');
    const statCardCorrectRatio = document.getElementById('statCardCorrectRatio');
    const statCardOverallAccuracy = document.getElementById('statCardOverallAccuracy');

    const chartTypeLineBtn = document.getElementById('chartTypeLineBtn');
    const chartTypeBarBtn = document.getElementById('chartTypeBarBtn');
    const scoreTrendChartCanvas = document.getElementById('scoreTrendChartCanvas');
    const chartEmptyState = document.getElementById('chartEmptyState');

    const historyCountBadge = document.getElementById('historyCountBadge');
    const quizHistoryTable = document.getElementById('quizHistoryTable');
    const quizHistoryTableBody = document.getElementById('quizHistoryTableBody');
    const historyEmptyState = document.getElementById('historyEmptyState');
    const historyStartQuizBtn = document.getElementById('historyStartQuizBtn');

    // DOM Elements - Restart Progress Modal & Alert
    const restartProgressBtn = document.getElementById('restartProgressBtn');
    const restartConfirmModal = document.getElementById('restartConfirmModal');
    const restartModalBackdrop = document.getElementById('restartModalBackdrop');
    const closeRestartModalBtn = document.getElementById('closeRestartModalBtn');
    const cancelRestartModalBtn = document.getElementById('cancelRestartModalBtn');
    const confirmRestartBtn = document.getElementById('confirmRestartBtn');
    const progressResetAlert = document.getElementById('progressResetAlert');
    const dismissResetAlertBtn = document.getElementById('dismissResetAlertBtn');
    let resetAlertTimeout = null;

    // DOM Elements - Phase 4: Word Help
    const wordHelpTriggerBtn = document.getElementById('wordHelpTriggerBtn');
    const resultsWordHelpBtn = document.getElementById('resultsWordHelpBtn');
    const wordHelpModal = document.getElementById('wordHelpModal');
    const wordHelpModalBackdrop = document.getElementById('wordHelpModalBackdrop');
    const closeWordHelpModalBtn = document.getElementById('closeWordHelpModalBtn');
    const cancelWordHelpModalBtn = document.getElementById('cancelWordHelpModalBtn');
    const wordHelpTargetFileName = document.getElementById('wordHelpTargetFileName');
    const wordHelpForm = document.getElementById('wordHelpForm');
    const wordHelpInput = document.getElementById('wordHelpInput');
    const wordHelpClearBtn = document.getElementById('wordHelpClearBtn');
    const wordHelpSubmitBtn = document.getElementById('wordHelpSubmitBtn');
    const wordHelpAlert = document.getElementById('wordHelpAlert');
    const wordHelpAlertMsg = document.getElementById('wordHelpAlertMsg');
    const wordHelpLoading = document.getElementById('wordHelpLoading');
    const wordHelpResult = document.getElementById('wordHelpResult');
    const wordHelpResultTerm = document.getElementById('wordHelpResultTerm');
    const wordHelpAnswerBody = document.getElementById('wordHelpAnswerBody');
    const closeWordHelpResultBtn = document.getElementById('closeWordHelpResultBtn');

    // DOM Elements - Feature Addons (Flashcards, Cheat Sheet, Streak, Achievements)
    const studyStreakBadge = document.getElementById('studyStreakBadge');
    const streakCountVal = document.getElementById('streakCountVal');
    const resultsFlashcardsBtn = document.getElementById('resultsFlashcardsBtn');
    const resultsCheatSheetBtn = document.getElementById('resultsCheatSheetBtn');

    // Streak Calendar Modal Elements
    const streakCalendarModal = document.getElementById('streakCalendarModal');
    const streakCalendarModalBackdrop = document.getElementById('streakCalendarModalBackdrop');
    const closeStreakCalendarModalBtn = document.getElementById('closeStreakCalendarModalBtn');
    const streakModalHeroCount = document.getElementById('streakModalHeroCount');
    const streakModalHeroStatus = document.getElementById('streakModalHeroStatus');
    const streakModalBestCount = document.getElementById('streakModalBestCount');
    const streakModalTotalWorked = document.getElementById('streakModalTotalWorked');
    const streakModalMonthWorked = document.getElementById('streakModalMonthWorked');
    const streakCalMonthTitle = document.getElementById('streakCalMonthTitle');
    const streakCalPrevMonthBtn = document.getElementById('streakCalPrevMonthBtn');
    const streakCalTodayBtn = document.getElementById('streakCalTodayBtn');
    const streakCalNextMonthBtn = document.getElementById('streakCalNextMonthBtn');
    const streakDaysGrid = document.getElementById('streakDaysGrid');

    // Achievements Showcase Elements
    const achievementsCard = document.getElementById('achievementsCard');
    const achievementsUnlockedBadge = document.getElementById('achievementsUnlockedBadge');
    const achFirstQuiz = document.getElementById('achFirstQuiz');
    const achSharpScholar = document.getElementById('achSharpScholar');
    const achTierAscendant = document.getElementById('achTierAscendant');
    const achDedicatedMind = document.getElementById('achDedicatedMind');
    const achPerfectionist = document.getElementById('achPerfectionist');
    const achStreakMaster = document.getElementById('achStreakMaster');

    // Flashcards Modal Elements
    const flashcardsModal = document.getElementById('flashcardsModal');
    const flashcardsModalBackdrop = document.getElementById('flashcardsModalBackdrop');
    const closeFlashcardsModalBtn = document.getElementById('closeFlashcardsModalBtn');
    const flashcardDocSubtitle = document.getElementById('flashcardDocSubtitle') || document.querySelector('.flashcards-modal-header .quiz-modal-subtitle');
    const flashcardProgress = document.getElementById('flashcardsProgressPill') || document.getElementById('flashcardProgress');
    const flashcardsMeterFill = document.getElementById('flashcardsMeterFill');
    const flashcardMasteredCount = document.getElementById('flashcardsMasteredPill') || document.getElementById('flashcardMasteredCount');
    const flashcardCard = document.getElementById('flashcardElement') || document.getElementById('flashcardCard');
    const cardQuestionText = document.getElementById('cardPromptText') || document.getElementById('cardQuestionText');
    const cardAnswerText = document.getElementById('cardAnswerText');
    const cardCategoryBadge = document.getElementById('cardCategoryBadge');
    const flashcardPrevBtn = document.getElementById('flashcardPrevBtn');
    const flashcardNextBtn = document.getElementById('flashcardNextBtn');
    const cardReviewAgainBtn = document.getElementById('cardReviewAgainBtn');
    const flashcardFlipBtn = document.getElementById('flashcardFlipBtn');
    const cardMasteredBtn = document.getElementById('cardMasteredBtn');

    // Exam Cheat Sheet Modal Elements
    const cheatSheetModal = document.getElementById('cheatSheetModal');
    const cheatSheetModalBackdrop = document.getElementById('cheatSheetModalBackdrop');
    const closeCheatSheetModalBtn = document.getElementById('closeCheatSheetModalBtn');
    const cheatSheetDocSubtitle = document.getElementById('cheatSheetDocSubtitle');
    const printCheatSheetBtn = document.getElementById('printCheatSheetBtn');
    const cheatSheetPrintArea = document.getElementById('cheatSheetPrintArea');
    const cheatSheetDate = document.getElementById('cheatSheetDate');
    const cheatSheetDocTitle = document.getElementById('cheatSheetDocTitle');
    const cheatSheetBigIdeas = document.getElementById('cheatSheetBigIdeas');
    const cheatSheetFormulas = document.getElementById('cheatSheetFormulas');
    const cheatSheetTerms = document.getElementById('cheatSheetTerms');
    const cheatSheetTraps = document.getElementById('cheatSheetTraps');

    // Progress Dashboard State
    let progressChartInstance = null;
    let currentChartType = 'line';
    let previousViewBeforeProgress = 'upload';
    let cachedQuizHistory = [];

    // Application State
    let selectedFile = null;
    let summariesData = null;
    let currentMode = 'easy';
    let statusInterval = null;
    let pendingAction = null;

    // Quiz State & Decision Options
    let selectedNumQuestions = null;
    let selectedDifficulty = null;
    let activeQuizDifficulty = 'medium';
    let quizQuestions = [];
    let currentQuestionIndex = 0;
    let quizScore = 0;
    let timerSeconds = 30;
    let timerInterval = null;
    let isQuestionAnswered = false;

    // Helper: format file size
    function formatBytes(bytes, decimals = 1) {
        if (!+bytes) return '0 Bytes';
        const k = 1024;
        const dm = decimals < 0 ? 0 : decimals;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return `${parseFloat((bytes / Math.pow(k, i)).toFixed(dm))} ${sizes[i]}`;
    }

    // Helper: Safely parse JSON from API response, validating status & content-type
    async function safeParseJsonResponse(response, actionDescription = 'request') {
        const contentType = response.headers.get('content-type') || '';
        const isJson = contentType.toLowerCase().includes('application/json');

        if (!isJson) {
            let errorDetails = '';
            try {
                const text = await response.text();
                // Strip HTML tags to extract readable snippet if present
                const cleanText = text.replace(/<[^>]*>?/gm, ' ').replace(/\s+/g, ' ').trim();
                errorDetails = cleanText.slice(0, 160);
            } catch (e) {
                errorDetails = '';
            }

            if (response.status === 504 || response.status === 502) {
                throw new Error(
                    `Server timeout (${response.status}). The AI model or document processing took too long to respond. Please try again or test with a smaller PDF.`
                );
            }
            if (response.status === 404) {
                throw new Error(`Endpoint not found (404). Please verify your deployment URL and routing.`);
            }
            if (response.status === 500) {
                const detailMsg = errorDetails ? ` (Server message: "${errorDetails}")` : '';
                throw new Error(
                    `Server Error (500).${detailMsg} Please check your hosting dashboard logs and ensure GEMINI_API_KEY is configured in Environment settings.`
                );
            }
            if (response.status === 413) {
                throw new Error(`File size is too large (413). Please upload a PDF under 30MB.`);
            }

            throw new Error(
                `Server returned an HTML error instead of JSON (${response.status}): ${errorDetails || 'Non-JSON response received.'}`
            );
        }

        let data;
        try {
            data = await response.json();
        } catch (jsonErr) {
            throw new Error(`Unable to parse server response as valid JSON: ${jsonErr.message}`);
        }

        if (!response.ok || (data && data.success === false)) {
            const errorMsg = (data && (data.error || data.message)) || `Failed during ${actionDescription}.`;
            if (response.status === 503 || errorMsg.includes('503') || errorMsg.toLowerCase().includes('busy')) {
                throw new Error('The service is busy right now, please try again in a minute.');
            }
            throw new Error(errorMsg);
        }

        return data;
    }

    // Helper: fetch JSON with one automatic retry. The Progress dashboard loads
    // history and stats as two separate requests; without a retry a single
    // transient failure (e.g. brief "database is locked") leaves the stat cards
    // showing data while the chart/history show empty, or vice versa.
    async function fetchJsonWithRetry(url, actionDescription, retries = 1) {
        let lastErr = null;
        for (let attempt = 0; attempt <= retries; attempt++) {
            try {
                const r = await fetch(url);
                return await safeParseJsonResponse(r, actionDescription);
            } catch (err) {
                lastErr = err;
                if (attempt < retries) {
                    await new Promise(res => setTimeout(res, 600));
                }
            }
        }
        throw lastErr;
    }

    // File selection handler
    function handleFile(file) {
        if (!file) return;

        if (file.type !== 'application/pdf' && !file.name.toLowerCase().endsWith('.pdf')) {
            showError('Please select a valid PDF document (.pdf).');
            return;
        }

        const maxSize = 30 * 1024 * 1024;
        if (file.size > maxSize) {
            showError('File size exceeds the 30MB limit.');
            return;
        }

        hideError();
        selectedFile = file;
        quizQuestions = []; // Reset cached quiz for new file
        fileNameSpan.textContent = file.name;
        fileSizeSpan.textContent = formatBytes(file.size);

        uploadContent.classList.add('hidden');
        fileInfo.classList.remove('hidden');
        submitBtn.classList.add('file-ready');
        if (uploadQuizBtn) uploadQuizBtn.classList.add('file-ready');
        hideWordHelpAlert();

        // Execute any action the user clicked prior to picking the file
        if (pendingAction === 'quiz') {
            pendingAction = null;
            setTimeout(() => openQuizConfigModal(), 120);
        } else if (pendingAction === 'summarize') {
            pendingAction = null;
            setTimeout(() => submitBtn.click(), 120);
        }
    }

    // Reset selected file
    function resetFile() {
        selectedFile = null;
        summariesData = null;
        quizQuestions = [];
        pendingAction = null;
        fileInput.value = '';
        uploadContent.classList.remove('hidden');
        fileInfo.classList.add('hidden');
        submitBtn.classList.remove('file-ready');
        if (uploadQuizBtn) uploadQuizBtn.classList.remove('file-ready');
        hideWordHelpAlert();
        if (wordHelpResult) wordHelpResult.classList.add('hidden');
    }

    // Error helpers
    function showError(msg) {
        const friendlyMessage = 'The service is busy right now, please try again in a minute.';
        const msgStr = String(msg || '');
        const isTemporary = (
            msgStr.includes('503') ||
            msgStr.toLowerCase().includes('unavailable') ||
            msgStr.toLowerCase().includes('busy') ||
            msgStr.includes('429') ||
            msgStr.toLowerCase().includes('resource_exhausted') ||
            msgStr.toLowerCase().includes('overloaded') ||
            msgStr.toLowerCase().includes('try again')
        );

        if (isTemporary) {
            errorText.textContent = friendlyMessage;
        } else {
            errorText.textContent = msgStr;
        }
        errorMessage.classList.remove('hidden');
    }

    function hideError() {
        errorMessage.classList.add('hidden');
    }

    dismissErrorBtn.addEventListener('click', hideError);

    // Drag and drop events
    ['dragenter', 'dragover'].forEach(eventName => {
        dropZone.addEventListener(eventName, (e) => {
            e.preventDefault();
            e.stopPropagation();
            dropZone.classList.add('dragover');
        });
    });

    ['dragleave', 'drop'].forEach(eventName => {
        dropZone.addEventListener(eventName, (e) => {
            e.preventDefault();
            e.stopPropagation();
            dropZone.classList.remove('dragover');
        });
    });

    dropZone.addEventListener('drop', (e) => {
        const dt = e.dataTransfer;
        if (dt.files && dt.files.length > 0) {
            handleFile(dt.files[0]);
        }
    });

    fileInput.addEventListener('change', (e) => {
        if (e.target.files && e.target.files.length > 0) {
            handleFile(e.target.files[0]);
        }
    });

    removeFileBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        resetFile();
    });

    // Loading status cycling
    const summaryLoadingSteps = [
        'Uploading and analyzing document...',
        'Analyzing document structure and concepts...',
        'Synthesizing Easy Mode for beginners...',
        'Extracting technical deep-dive insights...',
        'Adding analogies and lively fun tone...',
        'Finalizing summaries...'
    ];

    const quizLoadingSteps = [
        'Uploading and analyzing document...',
        'Reading document sections and core topics...',
        'Crafting challenging multiple-choice questions...',
        'Verifying options, correct answers, and explanations...',
        'Finalizing your interactive quiz...'
    ];

    function startLoadingAnimation(title, steps) {
        if (loadingTitle) loadingTitle.textContent = title || 'Analyzing your document...';
        let stepIdx = 0;
        loadingStatus.textContent = steps[0];
        statusInterval = setInterval(() => {
            stepIdx = (stepIdx + 1) % steps.length;
            loadingStatus.textContent = steps[stepIdx];
        }, 2200);
    }

    function stopLoadingAnimation() {
        if (statusInterval) {
            clearInterval(statusInterval);
            statusInterval = null;
        }
    }

    // Helper: Render LaTeX math in element using KaTeX auto-render
    function renderMath(element) {
        if (!element) return;
        const autoRender = () => {
            if (typeof renderMathInElement === 'function') {
                try {
                    renderMathInElement(element, {
                        delimiters: [
                            { left: '$$', right: '$$', display: true },
                            { left: '$', right: '$', display: false },
                            { left: '\\(', right: '\\)', display: false },
                            { left: '\\[', right: '\\]', display: true }
                        ],
                        throwOnError: false,
                        errorColor: '#ef4444'
                    });
                } catch (err) {
                    console.warn('KaTeX auto-render error:', err);
                }
            }
        };

        if (typeof renderMathInElement === 'function') {
            autoRender();
        } else {
            // Fallback retry if CDN script is still downloading
            let attempts = 0;
            const interval = setInterval(() => {
                attempts++;
                if (typeof renderMathInElement === 'function') {
                    clearInterval(interval);
                    autoRender();
                } else if (attempts > 20) {
                    clearInterval(interval);
                }
            }, 100);
        }
    }

    // Switch summary modes with smooth animation
    function switchMode(mode) {
        if (!summariesData || !summariesData[mode]) return;
        currentMode = mode;

        modeButtons.forEach(btn => {
            const isActive = btn.dataset.mode === mode;
            btn.classList.toggle('active', isActive);
            btn.setAttribute('aria-selected', isActive ? 'true' : 'false');
        });

        activeModeBadge.className = `mode-badge ${mode}`;
        if (mode === 'easy') {
            activeModeBadge.textContent = '🌱 Easy Mode (Beginner)';
        } else if (mode === 'deep') {
            activeModeBadge.textContent = '🔬 Deep Mode (Technical)';
        } else if (mode === 'fun') {
            activeModeBadge.textContent = '🚀 Fun Mode (Analogies & Emojis)';
        }

        summaryContent.classList.add('switching');
        setTimeout(() => {
            const markdownText = summariesData[mode] || 'No summary available for this mode.';
            summaryContent.innerHTML = marked.parse(markdownText);
            // Run KaTeX auto-render script so all LaTeX notation converts into formatted math
            renderMath(summaryContent);
            summaryContent.classList.remove('switching');
            summaryContent.classList.add('active');
        }, 200);
    }

    // Submit and Generate Summaries handler
    submitBtn.addEventListener('click', async () => {
        if (!selectedFile) {
            // Give instant glowing pulse to drop zone and prompt user to choose a PDF
            dropZone.classList.remove('pulse-highlight');
            void dropZone.offsetWidth;
            dropZone.classList.add('pulse-highlight');
            setTimeout(() => dropZone.classList.remove('pulse-highlight'), 1200);
            pendingAction = 'summarize';
            fileInput.click();
            return;
        }

        hideError();
        uploadSection.classList.add('hidden');
        quizSection.classList.add('hidden');
        resultsSection.classList.add('hidden');
        loadingSection.classList.remove('hidden');
        startLoadingAnimation('Analyzing your document...', summaryLoadingSteps);

        const formData = new FormData();
        formData.append('pdf', selectedFile);

        try {
            const response = await fetch('/summarize', {
                method: 'POST',
                body: formData
            });

            const data = await safeParseJsonResponse(response, 'summarizing document');

            summariesData = data.summaries;
            resultDocName.textContent = data.filename || selectedFile.name;

            stopLoadingAnimation();
            loadingSection.classList.add('hidden');
            resultsSection.classList.remove('hidden');
            switchMode('easy');
            recordStudyActivity();

        } catch (err) {
            console.error(err);
            stopLoadingAnimation();
            loadingSection.classList.add('hidden');
            uploadSection.classList.remove('hidden');
            showError(err.message || 'An error occurred while communicating with the server.');
        }
    });

    // Mode tab buttons click
    modeButtons.forEach(btn => {
        btn.addEventListener('click', () => {
            switchMode(btn.dataset.mode);
        });
    });

    // Copy to clipboard
    copyBtn.addEventListener('click', () => {
        if (!summariesData || !summariesData[currentMode]) return;
        navigator.clipboard.writeText(summariesData[currentMode]).then(() => {
            copyBtn.classList.add('copied');
            const copyText = copyBtn.querySelector('.copy-text');
            const originalText = copyText.textContent;
            copyText.textContent = 'Copied!';
            setTimeout(() => {
                copyBtn.classList.remove('copied');
                copyText.textContent = originalText;
            }, 2000);
        }).catch(() => {
            showError('Unable to copy to clipboard.');
        });
    });

    // Reset and upload another PDF
    newUploadBtn.addEventListener('click', () => {
        resetFile();
        resultsSection.classList.add('hidden');
        quizSection.classList.add('hidden');
        uploadSection.classList.remove('hidden');
    });

    if (quizNewUploadBtn) {
        quizNewUploadBtn.addEventListener('click', () => {
            resetFile();
            resultsSection.classList.add('hidden');
            quizSection.classList.add('hidden');
            uploadSection.classList.remove('hidden');
        });
    }

    /* ----------------------------------------------------
       QUIZ MODE LOGIC & ANIMATIONS
    ---------------------------------------------------- */

    // Confetti animation helper (with canvas-confetti & fallback)
    function triggerConfetti(isGrandCelebration = false) {
        if (typeof confetti === 'function') {
            if (isGrandCelebration) {
                // Multi-burst celebration for high scores
                const duration = 2500;
                const end = Date.now() + duration;
                (function frame() {
                    confetti({
                        particleCount: 5,
                        angle: 60,
                        spread: 55,
                        origin: { x: 0 }
                    });
                    confetti({
                        particleCount: 5,
                        angle: 120,
                        spread: 55,
                        origin: { x: 1 }
                    });
                    if (Date.now() < end) {
                        requestAnimationFrame(frame);
                    }
                }());
            } else {
                // Single question correct answer burst
                confetti({
                    particleCount: 45,
                    spread: 60,
                    origin: { y: 0.75 },
                    colors: ['#10b981', '#06b6d4', '#8b5cf6', '#f59e0b']
                });
            }
        }
    }

    // Trigger subtle shake animation on incorrect answer
    function triggerShake() {
        quizActiveCard.classList.remove('shake');
        // Force reflow
        void quizActiveCard.offsetWidth;
        quizActiveCard.classList.add('shake');
        setTimeout(() => {
            quizActiveCard.classList.remove('shake');
        }, 500);
    }

    // Helper: Format Difficulty Badge Display
    function formatDiffBadge(diff) {
        if (diff === 'easy') return '🌱 Easy';
        if (diff === 'hard') return '🔥 Hard';
        return '⚡ Medium';
    }

    // Helper: Update Dynamic Button Label in Customization Modal
    function updateStartQuizButtonLabel() {
        if (!startQuizBtnText) return;
        const num = selectedNumQuestions || 10;
        const diff = selectedDifficulty 
            ? (selectedDifficulty.charAt(0).toUpperCase() + selectedDifficulty.slice(1)) 
            : 'Medium';
        if (selectedNumQuestions || selectedDifficulty) {
            startQuizBtnText.textContent = `Start ${num}-Question Quiz (${diff})`;
        } else {
            startQuizBtnText.textContent = 'Start Quiz (10 Questions · Medium)';
        }
    }

    // Open Quiz Customization / Decision Modal
    function openQuizConfigModal() {
        if (!selectedFile) {
            showError('Please select or upload a PDF document first.');
            return;
        }
        hideError();
        if (quizTargetFileName) {
            quizTargetFileName.textContent = selectedFile.name;
        }

        // Sync pill buttons UI state without continuous glow or stuck focus
        quizPillBtns.forEach(btn => {
            const count = parseInt(btn.dataset.questions, 10);
            const isMatch = Boolean(selectedNumQuestions && count === selectedNumQuestions);
            btn.classList.toggle('active', isMatch);
            btn.setAttribute('aria-checked', isMatch ? 'true' : 'false');
            btn.classList.remove('glow-pulse');
            btn.blur();
        });

        // Sync difficulty cards UI state without continuous glow or stuck focus
        diffCardBtns.forEach(btn => {
            const diff = btn.dataset.difficulty;
            const isMatch = Boolean(selectedDifficulty && diff === selectedDifficulty);
            btn.classList.toggle('active', isMatch);
            btn.setAttribute('aria-checked', isMatch ? 'true' : 'false');
            btn.classList.remove('glow-pulse');
            btn.blur();
        });

        updateStartQuizButtonLabel();
        if (quizConfigModal) {
            quizConfigModal.classList.remove('hidden');
        }
    }

    // Close Quiz Customization Modal
    function closeQuizConfigModal() {
        if (quizConfigModal) {
            quizConfigModal.classList.add('hidden');
        }
    }

    // Generate & Start Quiz with selected count (10, 20, 30, 40, 50) and difficulty (easy, medium, hard)
    async function generateAndStartQuiz(numQuestions = 10, difficulty = 'medium') {
        if (!selectedFile) {
            showError('Please select or upload a PDF document first.');
            return;
        }

        const countToUse = numQuestions || selectedNumQuestions || 10;
        const diffToUse = difficulty || selectedDifficulty || 'medium';

        hideError();
        uploadSection.classList.add('hidden');
        resultsSection.classList.add('hidden');
        quizSection.classList.add('hidden');
        loadingSection.classList.remove('hidden');

        const capDiff = diffToUse.charAt(0).toUpperCase() + diffToUse.slice(1);
        startLoadingAnimation(`Crafting ${countToUse} ${capDiff} Questions...`, quizLoadingSteps);

        const formData = new FormData();
        formData.append('pdf', selectedFile);
        formData.append('num_questions', countToUse);
        formData.append('difficulty', diffToUse);

        try {
            const response = await fetch('/quiz/generate', {
                method: 'POST',
                body: formData
            });

            const data = await safeParseJsonResponse(response, 'generating quiz questions');

            if (!Array.isArray(data.questions) || data.questions.length === 0) {
                throw new Error('No quiz questions were returned. Please try again.');
            }

            quizQuestions = data.questions;
            activeQuizDifficulty = difficulty;
            stopLoadingAnimation();
            loadingSection.classList.add('hidden');
            startQuizSession();

        } catch (err) {
            console.error(err);
            stopLoadingAnimation();
            loadingSection.classList.add('hidden');
            if (summariesData) {
                resultsSection.classList.remove('hidden');
            } else {
                uploadSection.classList.remove('hidden');
            }
            showError(err.message || 'An error occurred while generating the quiz.');
        }
    }

    // Start Quiz Flow (prompts customization modal)
    function startQuizFlow() {
        openQuizConfigModal();
    }

    // Initialize Quiz Session
    function startQuizSession() {
        quizScore = 0;
        currentQuestionIndex = 0;
        isQuestionAnswered = false;

        quizDocName.textContent = selectedFile ? selectedFile.name : 'document.pdf';
        if (quizDifficultyBadge) {
            quizDifficultyBadge.textContent = formatDiffBadge(activeQuizDifficulty);
            quizDifficultyBadge.className = `quiz-badge difficulty ${activeQuizDifficulty}`;
        }
        quizCompletedCard.classList.add('hidden');
        quizActiveCard.classList.remove('hidden');
        quizSection.classList.remove('hidden');

        renderCurrentQuestion();
    }

    // 30-Second Timer Implementation
    function startTimer(seconds = 30) {
        clearInterval(timerInterval);
        timerSeconds = seconds;
        updateTimerDisplay(timerSeconds);

        quizTimerWrapper.classList.remove('warning', 'danger');

        timerInterval = setInterval(() => {
            timerSeconds--;
            updateTimerDisplay(timerSeconds);

            if (timerSeconds <= 10 && timerSeconds > 5) {
                quizTimerWrapper.classList.add('warning');
            } else if (timerSeconds <= 5) {
                quizTimerWrapper.classList.remove('warning');
                quizTimerWrapper.classList.add('danger');
            }

            if (timerSeconds <= 0) {
                clearInterval(timerInterval);
                handleTimeOut();
            }
        }, 1000);
    }

    function updateTimerDisplay(remaining) {
        timerText.textContent = remaining;
        // Stroke dasharray 100 max
        const offset = ((30 - remaining) / 30) * 100;
        timerCircle.setAttribute('stroke-dasharray', `${Math.max(0, 100 - offset)}, 100`);
    }

    function stopTimer() {
        if (timerInterval) {
            clearInterval(timerInterval);
            timerInterval = null;
        }
    }

    // Render Question
    function renderCurrentQuestion() {
        if (currentQuestionIndex >= quizQuestions.length) {
            finishQuiz();
            return;
        }

        const q = quizQuestions[currentQuestionIndex];
        isQuestionAnswered = false;

        // Update progress indicators
        const progressPct = ((currentQuestionIndex + 1) / quizQuestions.length) * 100;
        quizProgressBarFill.style.width = `${progressPct}%`;
        quizQuestionCounter.textContent = `Question ${currentQuestionIndex + 1} / ${quizQuestions.length}`;
        quizScoreCounter.textContent = `Score: ${quizScore} / ${quizQuestions.length}`;
        qTag.textContent = `QUESTION ${currentQuestionIndex + 1}`;

        // Reset UI states
        quizQuestionText.textContent = q.question;
        quizExplanationBox.classList.add('hidden');
        quizExplanationBox.className = 'quiz-explanation-box hidden';
        nextQuestionBtn.classList.add('hidden');

        // Render 4 Options
        quizOptionsContainer.innerHTML = '';
        const letters = ['A', 'B', 'C', 'D'];
        const options = Array.isArray(q.options) ? q.options : [];

        options.forEach((optText, idx) => {
            const letter = letters[idx] || `${idx + 1}`;
            const btn = document.createElement('button');
            btn.type = 'button';
            btn.className = 'quiz-option-btn';
            btn.dataset.option = optText;

            btn.innerHTML = `
                <span class="quiz-option-letter">${letter}</span>
                <span class="quiz-option-text">${optText}</span>
                <span class="quiz-option-icon"></span>
            `;

            btn.addEventListener('click', () => {
                handleOptionClick(btn, optText, q);
            });

            quizOptionsContainer.appendChild(btn);
        });

        // Start 30-second timer for this question
        startTimer(30);

        // Render KaTeX math formulas in question text & options
        renderMath(quizActiveCard);
    }

    // Option Click Handler
    function handleOptionClick(selectedBtn, selectedText, q) {
        if (isQuestionAnswered) return;
        isQuestionAnswered = true;
        stopTimer();

        // Mark the chosen button as selected for highlighting glow
        selectedBtn.classList.add('selected');

        // Disable all option buttons
        const allOptionBtns = quizOptionsContainer.querySelectorAll('.quiz-option-btn');
        allOptionBtns.forEach(btn => btn.classList.add('disabled'));

        const cleanSelected = String(selectedText).trim().toLowerCase();
        const cleanCorrect = String(q.correct_answer).trim().toLowerCase();
        const isCorrect = cleanSelected === cleanCorrect;

        if (isCorrect) {
            quizScore++;
            quizScoreCounter.textContent = `Score: ${quizScore} / ${quizQuestions.length}`;
            selectedBtn.classList.add('correct');
            const icon = selectedBtn.querySelector('.quiz-option-icon');
            if (icon) icon.textContent = '✓';

            // Confetti animation
            triggerConfetti(false);

            // Explanation box (success)
            explanationIcon.textContent = '🎉';
            explanationTitle.textContent = 'Correct Answer!';
            quizExplanationText.textContent = q.explanation || 'Great job! You identified the correct concept directly from the document.';
            quizExplanationBox.className = 'quiz-explanation-box correct';
            quizExplanationBox.classList.remove('hidden');
            renderMath(quizExplanationBox);

        } else {
            // Wrong answer
            selectedBtn.classList.add('wrong');
            const icon = selectedBtn.querySelector('.quiz-option-icon');
            if (icon) icon.textContent = '✗';

            // Subtle shake animation
            triggerShake();

            // Highlight the correct answer option
            allOptionBtns.forEach(btn => {
                if (String(btn.dataset.option).trim().toLowerCase() === cleanCorrect) {
                    btn.classList.add('correct-revealed');
                    const cIcon = btn.querySelector('.quiz-option-icon');
                    if (cIcon) cIcon.textContent = '✓';
                }
            });

            // Explanation box (failure)
            explanationIcon.textContent = '💡';
            explanationTitle.textContent = 'Incorrect';
            quizExplanationText.innerHTML = `<strong>Correct answer:</strong> ${q.correct_answer}<br><br>${q.explanation || ''}`;
            quizExplanationBox.className = 'quiz-explanation-box wrong';
            quizExplanationBox.classList.remove('hidden');
            renderMath(quizExplanationBox);
        }

        // Show Next Button
        const isLastQuestion = currentQuestionIndex === quizQuestions.length - 1;
        nextBtnText.textContent = isLastQuestion ? 'Finish & See Final Score 🏆' : 'Next Question';
        nextQuestionBtn.classList.remove('hidden');
    }

    // Time's Up Handler
    function handleTimeOut() {
        if (isQuestionAnswered) return;
        isQuestionAnswered = true;

        const q = quizQuestions[currentQuestionIndex];
        const allOptionBtns = quizOptionsContainer.querySelectorAll('.quiz-option-btn');
        allOptionBtns.forEach(btn => btn.classList.add('disabled'));

        triggerShake();

        // Highlight correct answer
        const cleanCorrect = String(q.correct_answer).trim().toLowerCase();
        allOptionBtns.forEach(btn => {
            if (String(btn.dataset.option).trim().toLowerCase() === cleanCorrect) {
                btn.classList.add('correct-revealed');
                const cIcon = btn.querySelector('.quiz-option-icon');
                if (cIcon) cIcon.textContent = '✓';
            }
        });

        explanationIcon.textContent = '⏰';
        explanationTitle.textContent = "Time's Up!";
        quizExplanationText.innerHTML = `You ran out of time for this question.<br><strong>Correct answer:</strong> ${q.correct_answer}<br><br>${q.explanation || ''}`;
        quizExplanationBox.className = 'quiz-explanation-box wrong';
        quizExplanationBox.classList.remove('hidden');
        renderMath(quizExplanationBox);

        const isLastQuestion = currentQuestionIndex === quizQuestions.length - 1;
        nextBtnText.textContent = isLastQuestion ? 'Finish & See Final Score 🏆' : 'Next Question';
        nextQuestionBtn.classList.remove('hidden');
    }

    // Next Question Button Click
    nextQuestionBtn.addEventListener('click', () => {
        currentQuestionIndex++;
        renderCurrentQuestion();
    });

    // Finish Quiz & Show Results
    function finishQuiz() {
        stopTimer();
        quizActiveCard.classList.add('hidden');
        quizCompletedCard.classList.remove('hidden');

        const totalQ = quizQuestions.length || 1;
        finalScoreVal.textContent = quizScore;
        if (finalTotalVal) finalTotalVal.textContent = totalQ;
        if (statTotalQuestions) statTotalQuestions.textContent = `${totalQ}`;
        if (statDifficulty) statDifficulty.textContent = activeQuizDifficulty.toUpperCase();

        const accuracyPct = Math.round((quizScore / totalQ) * 100);
        statAccuracy.textContent = `${accuracyPct}%`;
        statCorrect.textContent = `${quizScore}`;

        // Dynamic, fun performance messages based on percentage & difficulty
        let title = '';
        let message = '';
        const capDiff = activeQuizDifficulty.charAt(0).toUpperCase() + activeQuizDifficulty.slice(1);

        if (accuracyPct === 100) {
            title = '🏆 Absolute Perfection!';
            message = `Flawless score! You achieved ${quizScore}/${totalQ} on ${capDiff} mode! You have total mastery of this document's content down to every detail!`;
            triggerConfetti(true);
        } else if (accuracyPct >= 80) {
            title = '🌟 Outstanding Scholar!';
            message = `Phenomenal work! You scored ${quizScore}/${totalQ} on ${capDiff} mode. You grasp the core concepts, arguments, and takeaways with ease!`;
            triggerConfetti(true);
        } else if (accuracyPct >= 60) {
            title = '👏 Solid Understanding!';
            message = `Great effort! You scored ${quizScore}/${totalQ} on ${capDiff} mode. You've got the primary foundations down, with just a couple of nuanced areas to polish.`;
        } else if (accuracyPct >= 40) {
            title = '📚 Fair Effort!';
            message = `A decent try! You scored ${quizScore}/${totalQ} on ${capDiff} mode. A quick re-read of the Deep Mode summary will help lock in the trickier questions.`;
        } else {
            title = '🌱 Keep Going!';
            message = `Every quiz is a step forward! You scored ${quizScore}/${totalQ}. Review the summary and give it another shot — you've got this!`;
        }

        finalResultTitle.textContent = title;
        finalResultMsg.textContent = message;
        renderMath(quizCompletedCard);

        // Automatically persist quiz result to SQLite / JSON
        saveQuizResultToDatabase(quizScore, totalQ, accuracyPct, `${title} - ${message}`, activeQuizDifficulty);
        recordStudyActivity();
    }

    // Save Quiz Result Endpoint
    async function saveQuizResultToDatabase(score, total, percentage, performanceMessage, difficulty = 'medium') {
        try {
            const res = await fetch('/quiz/save', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    pdf_name: selectedFile ? selectedFile.name : 'document.pdf',
                    score: score,
                    total: total,
                    percentage: percentage,
                    difficulty: difficulty,
                    performance_message: performanceMessage,
                    created_at: new Date().toLocaleString()
                })
            });
            await safeParseJsonResponse(res, 'saving quiz result');
        } catch (err) {
            console.warn('Failed to save quiz result to database:', err);
        }
    }

    // Retake Quiz (retries same set of questions)
    retakeQuizBtn.addEventListener('click', () => {
        startQuizSession();
    });

    // Exit Quiz / Back to Summaries
    function exitQuiz() {
        stopTimer();
        quizSection.classList.add('hidden');
        if (summariesData) {
            resultsSection.classList.remove('hidden');
        } else {
            uploadSection.classList.remove('hidden');
        }
    }

    exitQuizBtn.addEventListener('click', exitQuiz);
    backToSummariesBtn.addEventListener('click', exitQuiz);

    // ========================================================
    // QUIZ CONFIGURATION / DECISION MODAL EVENT LISTENERS
    // ========================================================
    if (closeQuizModalBtn) closeQuizModalBtn.addEventListener('click', closeQuizConfigModal);
    if (cancelQuizModalBtn) cancelQuizModalBtn.addEventListener('click', closeQuizConfigModal);

    if (quizConfigModal) {
        quizConfigModal.addEventListener('click', (e) => {
            if (e.target === quizConfigModal || e.target.id === 'quizModalBackdrop' || e.target.classList.contains('quiz-modal-backdrop') || e.target.classList.contains('quiz-modal-dialog')) {
                closeQuizConfigModal();
            }
        });
    }

    window.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && quizConfigModal && !quizConfigModal.classList.contains('hidden')) {
            closeQuizConfigModal();
        }
    });

    // Question Count Pills (10, 20, 30, 40, 50) - smoothly toggle active state & blur button
    quizPillBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            const count = parseInt(btn.dataset.questions, 10);
            if (count) {
                selectedNumQuestions = count;
                quizPillBtns.forEach(b => {
                    b.classList.remove('active', 'glow-pulse');
                    b.setAttribute('aria-checked', 'false');
                });
                btn.classList.add('active');
                btn.setAttribute('aria-checked', 'true');
                updateStartQuizButtonLabel();
                // Remove stuck hover/focus effect immediately after click
                btn.blur();
            }
        });
    });

    // Difficulty Option Cards (Easy, Medium, Hard) - smoothly toggle active state & blur button
    diffCardBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            const diff = btn.dataset.difficulty;
            if (diff) {
                selectedDifficulty = diff;
                diffCardBtns.forEach(b => {
                    b.classList.remove('active', 'glow-pulse');
                    b.setAttribute('aria-checked', 'false');
                });
                btn.classList.add('active');
                btn.setAttribute('aria-checked', 'true');
                updateStartQuizButtonLabel();
                // Remove stuck hover/focus effect immediately after click
                btn.blur();
            }
        });
    });

    // Start Custom Quiz button from modal
    if (startCustomQuizBtn) {
        startCustomQuizBtn.addEventListener('click', () => {
            const count = selectedNumQuestions || 10;
            const diff = selectedDifficulty || 'medium';
            closeQuizConfigModal();
            generateAndStartQuiz(count, diff);
        });
    }

    // Change Settings button on completed card
    if (changeQuizSettingsBtn) {
        changeQuizSettingsBtn.addEventListener('click', () => {
            openQuizConfigModal();
        });
    }

    // Event Listeners for Launching Quiz (opens Decision Modal)
    if (uploadQuizBtn) {
        uploadQuizBtn.addEventListener('click', () => {
            if (!selectedFile) {
                // Give instant glowing pulse to drop zone and open file picker
                dropZone.classList.remove('pulse-highlight');
                void dropZone.offsetWidth;
                dropZone.classList.add('pulse-highlight');
                setTimeout(() => dropZone.classList.remove('pulse-highlight'), 1200);
                pendingAction = 'quiz';
                fileInput.click();
                return;
            }
            openQuizConfigModal();
        });
    }
    if (resultsQuizBtn) resultsQuizBtn.addEventListener('click', openQuizConfigModal);
    if (summaryQuizCtaBtn) summaryQuizCtaBtn.addEventListener('click', openQuizConfigModal);

    // ========================================================
    // DYNAMIC SELECTION GLOW EFFECT FOR ALL BUTTONS & OPTIONS
    // ========================================================
    document.addEventListener('click', (e) => {
        const targetBtn = e.target.closest('button, .quiz-option-btn, .mode-btn');
        if (targetBtn && !targetBtn.classList.contains('quiz-pill-btn') && !targetBtn.classList.contains('diff-card-btn')) {
            targetBtn.classList.remove('glow-pulse');
            void targetBtn.offsetWidth; // Force reflow to re-trigger glow pulse animation
            targetBtn.classList.add('glow-pulse');
            setTimeout(() => {
                targetBtn.classList.remove('glow-pulse');
            }, 600);
        }
    });

    // ========================================================
    // PARTICLE DRIFT: ASCII & LASER BEAM CANVAS ENGINE
    // ========================================================
    function initParticleDrift(canvas, wrapper, options = {}) {
        if (!canvas || !wrapper) return null;

        let currentTheme = options.theme || document.documentElement.getAttribute('data-theme') || 'dark';

        let width = 0;
        let height = 0;
        let nodes = [];
        let beams = [];
        const chars = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ@#$%&*()'.split('');
        const mouse = { x: -1000, y: -1000 };
        let rafId = null;

        function getColors() {
            const isLight = currentTheme === 'light';
            return {
                isLight,
                accentRgb: isLight ? '37, 99, 235' : '96, 165, 250',
                accentHex: isLight ? '#2563EB' : '#60A5FA',
                mutedRgb: isLight ? '36, 48, 68' : '156, 163, 175',
                proximityAlpha: isLight ? 0.22 : 0.15,
                textAlpha: isLight ? 0.55 : 0.4
            };
        }

        let colors = getColors();

        function resize() {
            width = wrapper.clientWidth || window.innerWidth;
            height = wrapper.clientHeight || window.innerHeight;
            const dpr = window.devicePixelRatio || 1;
            canvas.width = Math.floor(width * dpr);
            canvas.height = Math.floor(height * dpr);
            canvas.style.width = `${width}px`;
            canvas.style.height = `${height}px`;

            const ctx = canvas.getContext('2d');
            if (ctx) ctx.scale(dpr, dpr);
        }

        function initParticles() {
            const density = options.density ?? 1;
            const nodeCount = Math.max(12, Math.round(90 * density));
            const beamCount = Math.max(4, Math.round(25 * density));

            nodes = Array.from({ length: nodeCount }).map(() => ({
                x: Math.random() * (width || window.innerWidth),
                y: Math.random() * (height || window.innerHeight),
                vy: (Math.random() * 0.4) + 0.1,
                char: chars[Math.floor(Math.random() * chars.length)]
            }));

            beams = Array.from({ length: beamCount }).map(() => ({
                x: Math.random() * (width || window.innerWidth),
                y: Math.random() * (height || window.innerHeight),
                length: (Math.random() * 100 + 50) * (options.length ?? 1),
                speed: (Math.random() * 6) + 3,
                opacity: Math.random() * 0.5 + 0.3
            }));
        }

        function onMouseMove(e) {
            const rect = canvas.getBoundingClientRect();
            mouse.x = e.clientX - rect.left;
            mouse.y = e.clientY - rect.top;
        }

        function onMouseLeave() {
            mouse.x = -1000;
            mouse.y = -1000;
        }

        function draw() {
            const ctx = canvas.getContext('2d');
            if (!ctx) return;
            ctx.clearRect(0, 0, width, height);

            // 1. Upward Beams (Laser / Particle Trails)
            const speedMod = options.speed ?? 1;
            beams.forEach(b => {
                b.y -= b.speed * speedMod;
                if (b.y + b.length < 0) {
                    b.y = height + 100;
                    b.x = Math.random() * width;
                }
                const g = ctx.createLinearGradient(b.x, b.y, b.x, b.y + b.length);
                g.addColorStop(0, `rgba(${colors.accentRgb}, ${b.opacity})`);
                g.addColorStop(1, 'transparent');
                ctx.strokeStyle = g;
                ctx.lineWidth = 1.5 * (options.size ?? 1);
                ctx.beginPath();
                ctx.moveTo(b.x, b.y);
                ctx.lineTo(b.x, b.y + b.length);
                ctx.stroke();
            });

            // 2. Interactive ASCII Nodes & Constellation Lines
            ctx.font = '12px "JetBrains Mono", Menlo, Monaco, Consolas, monospace';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';

            // Proximity Lines between nodes
            ctx.lineWidth = 0.5;
            const maxLink = Math.round(120 * (options.length ?? 1));
            for (let i = 0; i < nodes.length; i++) {
                const n1 = nodes[i];
                for (let j = i + 1; j < nodes.length; j++) {
                    const n2 = nodes[j];
                    const d = Math.hypot(n1.x - n2.x, n1.y - n2.y);
                    if (d < maxLink) {
                        ctx.strokeStyle = `rgba(${colors.mutedRgb}, ${colors.proximityAlpha * (1 - d / maxLink)})`;
                        ctx.beginPath();
                        ctx.moveTo(n1.x, n1.y);
                        ctx.lineTo(n2.x, n2.y);
                        ctx.stroke();
                    }
                }
            }

            nodes.forEach(n => {
                n.y += n.vy * speedMod; // Slow drift
                if (n.y > height + 20) {
                    n.y = -20;
                    n.x = Math.random() * width;
                }

                const dist = Math.hypot(mouse.x - n.x, mouse.y - n.y);

                // Dynamic Character Swap
                if (dist < 180 || Math.random() > 0.985) {
                    n.char = chars[Math.floor(Math.random() * chars.length)];
                }

                // Mouse Connection Line
                if (dist < 180) {
                    ctx.strokeStyle = `rgba(${colors.accentRgb}, ${0.5 * (1 - dist / 180)})`;
                    ctx.beginPath();
                    ctx.moveTo(n.x, n.y);
                    ctx.lineTo(mouse.x, mouse.y);
                    ctx.stroke();
                }

                ctx.fillStyle = dist < 180 ? colors.accentHex : `rgba(${colors.mutedRgb}, ${colors.textAlpha})`;
                ctx.fillText(n.char, n.x, n.y);
            });

            rafId = requestAnimationFrame(draw);
        }

        resize();
        initParticles();
        draw();

        let ro = null;
        if ('ResizeObserver' in window) {
            ro = new ResizeObserver(() => {
                resize();
            });
            ro.observe(wrapper);
        } else {
            window.addEventListener('resize', resize);
        }

        window.addEventListener('mousemove', onMouseMove, { passive: true });
        document.addEventListener('mouseleave', onMouseLeave);

        return {
            setTheme(newTheme) {
                currentTheme = newTheme;
                colors = getColors();
            },
            destroy() {
                if (rafId) cancelAnimationFrame(rafId);
                if (ro) ro.disconnect();
                window.removeEventListener('resize', resize);
                window.removeEventListener('mousemove', onMouseMove);
                document.removeEventListener('mouseleave', onMouseLeave);
            }
        };
    }

    // Initialize Particle Drift Interactive Background System
    const particleWrapper = document.getElementById('particleDriftBackground');
    const particleCanvas = document.getElementById('particle-canvas');
    let particleInstance = null;

    if (particleWrapper && particleCanvas) {
        const initialTheme = document.documentElement.getAttribute('data-theme') || 'dark';
        particleInstance = initParticleDrift(particleCanvas, particleWrapper, {
            theme: initialTheme
        });
    }

    // ========================================================
    // THEME SWITCHER (DARK / LIGHT MODE - UIVERSE GALAHHAD SWITCH)
    // ========================================================
    const themeSwitchCheckbox = document.getElementById('themeSwitchCheckbox');
    const themeSwitchLabel = document.getElementById('themeSwitchLabel');
    const themeToggleBtn = document.getElementById('themeToggleBtn');
    const themeToggleLabel = document.getElementById('themeToggleLabel');

    function applyTheme(theme) {
        document.documentElement.setAttribute('data-theme', theme);
        localStorage.setItem('studysnap-theme', theme);
        
        // Sync Uiverse day/night checkbox (checked = dark/night mode, unchecked = light/day mode)
        if (themeSwitchCheckbox) {
            themeSwitchCheckbox.checked = (theme === 'dark');
        }
        if (themeSwitchLabel) {
            const nextMode = theme === 'dark' ? 'Light' : 'Dark';
            themeSwitchLabel.setAttribute('title', `Switch to ${nextMode} mode`);
            themeSwitchLabel.setAttribute('aria-label', `Switch to ${nextMode} mode`);
        }

        if (themeToggleLabel) {
            themeToggleLabel.textContent = theme === 'dark' ? 'Light Mode' : 'Dark Mode';
        }
        if (themeToggleBtn) {
            const nextMode = theme === 'dark' ? 'light' : 'dark';
            themeToggleBtn.setAttribute('aria-label', `Switch to ${nextMode} mode`);
            themeToggleBtn.setAttribute('title', `Switch to ${nextMode} mode`);
        }
        if (particleInstance) {
            particleInstance.setTheme(theme);
        }
    }

    // Initialize theme from saved preference or default to dark
    const savedTheme = localStorage.getItem('studysnap-theme') || 'dark';
    applyTheme(savedTheme);

    // Event listener for Uiverse animated theme switch
    if (themeSwitchCheckbox) {
        themeSwitchCheckbox.addEventListener('change', () => {
            const newTheme = themeSwitchCheckbox.checked ? 'dark' : 'light';
            applyTheme(newTheme);
            if (progressSection && !progressSection.classList.contains('hidden') && cachedQuizHistory.length > 0) {
                renderScoreTrendChart(cachedQuizHistory, currentChartType);
            }
        });
    }

    if (themeToggleBtn) {
        themeToggleBtn.addEventListener('click', () => {
            const currentTheme = document.documentElement.getAttribute('data-theme') || 'dark';
            const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
            applyTheme(newTheme);
            if (progressSection && !progressSection.classList.contains('hidden') && cachedQuizHistory.length > 0) {
                renderScoreTrendChart(cachedQuizHistory, currentChartType);
            }
        });
    }

    // ========================================================
    // PHASE 3: PROGRESS DASHBOARD & GAMER STATS LOGIC
    // ========================================================

    // Format quiz date timestamp
    function formatQuizDate(dateStr) {
        if (!dateStr) return 'Recently';
        try {
            const d = new Date(dateStr);
            if (!isNaN(d.getTime())) {
                return d.toLocaleDateString(undefined, {
                    month: 'short',
                    day: 'numeric',
                    year: 'numeric',
                    hour: '2-digit',
                    minute: '2-digit'
                });
            }
        } catch (e) {
            // fallback
        }
        return dateStr;
    }

    // Get score badge styling class based on percentage
    function getScoreBadgeClass(pct) {
        if (pct >= 80) return 'score-master';
        if (pct >= 60) return 'score-scholar';
        if (pct >= 40) return 'score-learner';
        return 'score-beginner';
    }

    // Helpers: swap an empty-state panel to an error message and back.
    // Original heading/body/icon are cached on first use so a later successful
    // load restores the default text instead of keeping a stale error.
    function setPanelMessage(panel, iconText, headingText, bodyText) {
        if (!panel) return;
        if (iconText === null && headingText === null && bodyText === null) return;
        const iconEl = panel.querySelector('.history-empty-icon, .empty-icon');
        const headEl = panel.querySelector('h4');
        const bodyEl = panel.querySelector('p');
        // Cache originals as text (never replace innerHTML: the history empty
        // state contains the Start Quiz button with a live event listener).
        if (iconEl) {
            if (panel.dataset.origIcon === undefined) panel.dataset.origIcon = iconEl.textContent;
            if (iconText) iconEl.textContent = iconText;
        }
        if (headEl) {
            if (panel.dataset.origHead === undefined) panel.dataset.origHead = headEl.textContent;
            if (headingText) headEl.textContent = headingText;
        }
        if (bodyEl) {
            if (panel.dataset.origBody === undefined) panel.dataset.origBody = bodyEl.textContent;
            if (bodyText) bodyEl.textContent = bodyText;
        }
    }

    function restorePanelMessage(panel) {
        if (!panel) return;
        const iconEl = panel.querySelector('.history-empty-icon, .empty-icon');
        const headEl = panel.querySelector('h4');
        const bodyEl = panel.querySelector('p');
        if (iconEl && panel.dataset.origIcon !== undefined) iconEl.textContent = panel.dataset.origIcon;
        if (headEl && panel.dataset.origHead !== undefined) headEl.textContent = panel.dataset.origHead;
        if (bodyEl && panel.dataset.origBody !== undefined) bodyEl.textContent = panel.dataset.origBody;
        delete panel.dataset.origIcon;
        delete panel.dataset.origHead;
        delete panel.dataset.origBody;
    }

    // Render Quiz History Table (Newest first). loadError, when provided, is
    // shown in the empty state instead of silently displaying "no quizzes".
    function renderQuizHistoryTable(historyItems, loadError = null) {
        if (!quizHistoryTableBody) return;
        quizHistoryTableBody.innerHTML = '';

        if (!historyItems || historyItems.length === 0) {
            if (historyEmptyState) {
                setPanelMessage(
                    historyEmptyState,
                    loadError ? '⚠️' : null,
                    loadError ? "Couldn't Load History" : null,
                    loadError ? `History failed to load (${loadError}). Reopen My Progress to retry — your saved quizzes are not lost.` : null
                );
                historyEmptyState.classList.remove('hidden');
            }
            if (quizHistoryTable) quizHistoryTable.classList.add('hidden');
            if (historyCountBadge) historyCountBadge.textContent = loadError ? 'load failed' : '0 attempts';
            return;
        }

        if (historyEmptyState) {
            restorePanelMessage(historyEmptyState);
            historyEmptyState.classList.add('hidden');
        }
        if (quizHistoryTable) quizHistoryTable.classList.remove('hidden');
        if (historyCountBadge) historyCountBadge.textContent = `${historyItems.length} attempt${historyItems.length === 1 ? '' : 's'}`;

        historyItems.forEach(item => {
            if (!item) return;
            const tr = document.createElement('tr');
            const diff = String(item.difficulty || 'medium').toLowerCase();
            const diffIcon = diff === 'easy' ? '🌱' : diff === 'hard' ? '🔥' : '⚡';
            const diffLabel = diff.charAt(0).toUpperCase() + diff.slice(1);
            const scorePct = Math.round(parseFloat(item.percentage) || 0);
            const scoreClass = getScoreBadgeClass(scorePct);
            const formattedDate = formatQuizDate(item.created_at);

            tr.innerHTML = `
                <td class="td-date history-date">${formattedDate}</td>
                <td class="td-doc">
                    <div class="history-doc-wrap" title="${item.pdf_name || 'document.pdf'}">
                        <span class="history-doc-icon">📄</span>
                        <span class="history-doc-text">${item.pdf_name || 'document.pdf'}</span>
                    </div>
                </td>
                <td class="td-questions">
                    <span class="history-pill-questions">${item.total || 10} Qs</span>
                </td>
                <td class="td-difficulty">
                    <span class="badge-diff ${diff}">${diffIcon} ${diffLabel}</span>
                </td>
                <td class="td-score">
                    <span class="badge-score ${scoreClass}">
                        <span class="score-fraction">${item.score}/${item.total}</span>
                        <small class="score-pct-small">(${scorePct}%)</small>
                    </span>
                </td>
            `;
            quizHistoryTableBody.appendChild(tr);
        });
    }

    // Update Gamer Rank Banner & Animated Progress Bar to next level
    function updateRankBanner(stats) {
        if (!gamerRankBanner) return;

        const avg = typeof stats.average_score === 'number' ? stats.average_score : (parseFloat(stats.average_score) || 0);

        // Clamped average score between 0% and 100% for the progress meter
        const fillPercentage = Math.min(100, Math.max(0, avg));

        // Level badge system:
        // Beginner (<40%), Learner (40-60%), Scholar (60-80%), Master (80%+)
        let levelTitle = 'Beginner';
        let levelEmoji = '🌱';
        let tierPillText = 'TIER 1';
        let tierDesc = 'Starting your knowledge journey and building core foundational concepts.';
        let nextRankMsg = '';

        if (avg < 40) {
            levelTitle = 'Beginner';
            levelEmoji = '🌱';
            tierPillText = 'TIER 1';
            tierDesc = 'Starting your knowledge journey and building core foundational concepts.';
            nextRankMsg = `${(40 - avg).toFixed(1)}% to unlock Learner ⚡`;
        } else if (avg < 60) {
            levelTitle = 'Learner';
            levelEmoji = '⚡';
            tierPillText = 'TIER 2';
            tierDesc = 'Building strong conceptual understanding and practical comprehension.';
            nextRankMsg = `${(60 - avg).toFixed(1)}% to unlock Scholar 🔮`;
        } else if (avg < 80) {
            levelTitle = 'Scholar';
            levelEmoji = '🔮';
            tierPillText = 'TIER 3';
            tierDesc = 'Mastering complex technical nuances and analytical reasoning.';
            nextRankMsg = `${(80 - avg).toFixed(1)}% to unlock Master 👑`;
        } else if (avg < 100) {
            levelTitle = 'Master';
            levelEmoji = '👑';
            tierPillText = 'TIER 4';
            tierDesc = 'Apex Grandmaster! Exceptional retention and complete document mastery.';
            nextRankMsg = `${(100 - avg).toFixed(1)}% to unlock Impossible ♾️`;
        } else {
            levelTitle = 'Impossible';
            levelEmoji = '♾️';
            tierPillText = 'TIER 5';
            tierDesc = 'Transcendental Perfection! Flawless 100% accuracy — truly impossible mastery achieved!';
            nextRankMsg = 'MAX RANK UNLOCKED · Flawless Impossible Godlike! ♾️';
        }

        if (rankBadgeEmoji) rankBadgeEmoji.textContent = levelEmoji;
        if (rankTitle) rankTitle.textContent = levelTitle;
        if (rankTierPill) rankTierPill.textContent = tierPillText;
        if (rankDesc) rankDesc.textContent = tierDesc;
        if (rankAvgScoreDisplay) rankAvgScoreDisplay.textContent = `${avg.toFixed(1)}%`;
        if (nextRankLabel) nextRankLabel.textContent = nextRankMsg;

        if (rankProgressBar) {
            rankProgressBar.setAttribute('aria-valuenow', Math.round(fillPercentage));
        }
        if (rankProgressFill) {
            // Directly bind fill width to average score with smooth transition
            rankProgressFill.style.width = `${fillPercentage.toFixed(1)}%`;
        }

        // Highlight passed ticks on the 0-100 numeric scale
        const scaleTicks = gamerRankBanner.querySelectorAll('.scale-tick');
        scaleTicks.forEach(tick => {
            const val = parseFloat(tick.dataset.val);
            if (!isNaN(val)) {
                if (val <= fillPercentage) {
                    tick.classList.add('passed');
                } else {
                    tick.classList.remove('passed');
                }
            }
        });

        // Update active milestone step in the tier zones legend
        const tiers = ['beginner', 'learner', 'scholar', 'master', 'impossible'];
        const currentTierIndex = tiers.indexOf(levelTitle.toLowerCase());
        const stepEls = [tierStepBeginner, tierStepLearner, tierStepScholar, tierStepMaster, tierStepImpossible];

        stepEls.forEach((el, idx) => {
            if (!el) return;
            el.classList.remove('active-tier', 'completed-tier');
            if (idx === currentTierIndex) {
                el.classList.add('active-tier');
            } else if (idx < currentTierIndex) {
                el.classList.add('completed-tier');
            }
        });
    }

    // Update 5 Stats Overview Cards
    function updateStatsCards(stats, historyItems) {
        const totalQuizzes = stats.total_quizzes !== undefined ? stats.total_quizzes : historyItems.length;
        const avgScore = typeof stats.average_score === 'number' ? stats.average_score : (parseFloat(stats.average_score) || 0);
        const bestScore = stats.best_score || '0%';
        const totalQuestions = stats.total_questions !== undefined ? stats.total_questions : 0;
        const totalCorrect = stats.total_correct !== undefined ? stats.total_correct : 0;
        const overallAccuracy = typeof stats.overall_accuracy === 'number' ? stats.overall_accuracy : (parseFloat(stats.overall_accuracy) || 0);

        if (statCardTotalQuizzes) statCardTotalQuizzes.textContent = totalQuizzes;
        if (statCardAverageScore) statCardAverageScore.textContent = `${avgScore.toFixed(1)}%`;
        if (statCardBestScore) statCardBestScore.textContent = bestScore;
        if (statCardTotalQuestions) statCardTotalQuestions.textContent = totalQuestions;
        if (statCardCorrectRatio) statCardCorrectRatio.textContent = `${totalCorrect} correct answers`;
        if (statCardOverallAccuracy) statCardOverallAccuracy.textContent = `${overallAccuracy.toFixed(1)}%`;
    }

    // Render Score Trend Chart using Chart.js. loadError, when provided, is
    // shown in the chart panel instead of leaving it silently blank.
    function renderScoreTrendChart(historyItems, chartType = 'line', loadError = null) {
        if (!scoreTrendChartCanvas) return;
        if (typeof Chart === 'undefined') {
            console.warn('Chart.js library is not available.');
            if (chartEmptyState) {
                setPanelMessage(
                    chartEmptyState,
                    '⚠️',
                    null,
                    'Chart library failed to load (check connection or ad-blocker). Your stats and history below are unaffected — reload to retry.'
                );
                chartEmptyState.classList.remove('hidden');
            }
            scoreTrendChartCanvas.classList.add('hidden');
            return;
        }

        if (progressChartInstance) {
            progressChartInstance.destroy();
            progressChartInstance = null;
        }

        if (!historyItems || historyItems.length === 0) {
            if (chartEmptyState) {
                if (loadError) {
                    setPanelMessage(
                        chartEmptyState,
                        '⚠️',
                        null,
                        `Trend data failed to load (${loadError}). Reopen My Progress to retry — your saved quizzes are not lost.`
                    );
                } else {
                    restorePanelMessage(chartEmptyState);
                }
                chartEmptyState.classList.remove('hidden');
            }
            scoreTrendChartCanvas.classList.add('hidden');
            return;
        }

        if (chartEmptyState) {
            restorePanelMessage(chartEmptyState);
            chartEmptyState.classList.add('hidden');
        }
        scoreTrendChartCanvas.classList.remove('hidden');

        // Chronological order: oldest first for score progression over time
        const chronological = [...historyItems].reverse();

        const isDark = document.documentElement.getAttribute('data-theme') !== 'light';
        const textColor = isDark ? '#c4b5fd' : '#4c1d95';
        const gridColor = isDark ? 'rgba(168, 85, 247, 0.12)' : 'rgba(124, 58, 237, 0.1)';
        const tooltipBg = isDark ? 'rgba(20, 13, 38, 0.95)' : 'rgba(255, 255, 255, 0.98)';
        const tooltipText = isDark ? '#f8f6fe' : '#1e1b4b';

        const labels = chronological.map((item, idx) => {
            if (item && item.created_at) {
                const parts = String(item.created_at).split(/[\s,]+/);
                return parts[0] || `Quiz ${idx + 1}`;
            }
            return `Quiz ${idx + 1}`;
        });

        const dataPoints = chronological.map(item => parseFloat(item && item.percentage) || 0);

        const ctx = scoreTrendChartCanvas.getContext('2d');
        let gradientFill = null;
        let gradientStroke = null;

        try {
            const h = Math.max(scoreTrendChartCanvas.clientHeight || 280, 200);
            const w = Math.max(scoreTrendChartCanvas.clientWidth || 400, 300);
            gradientFill = ctx.createLinearGradient(0, 0, 0, h);
            gradientFill.addColorStop(0, 'rgba(168, 85, 247, 0.45)');
            gradientFill.addColorStop(0.6, 'rgba(6, 182, 212, 0.15)');
            gradientFill.addColorStop(1, 'rgba(12, 8, 23, 0.0)');

            gradientStroke = ctx.createLinearGradient(0, 0, w, 0);
            gradientStroke.addColorStop(0, '#a855f7');
            gradientStroke.addColorStop(1, '#06b6d4');
        } catch (e) {
            gradientFill = 'rgba(168, 85, 247, 0.25)';
            gradientStroke = '#a855f7';
        }

        progressChartInstance = new Chart(ctx, {
            type: chartType,
            data: {
                labels: labels,
                datasets: [{
                    label: 'Quiz Score (%)',
                    data: dataPoints,
                    borderColor: gradientStroke || '#a855f7',
                    backgroundColor: chartType === 'line' ? gradientFill : 'rgba(168, 85, 247, 0.65)',
                    borderWidth: 2.5,
                    fill: chartType === 'line',
                    tension: 0.35,
                    pointBackgroundColor: '#22d3ee',
                    pointBorderColor: isDark ? '#0c0817' : '#ffffff',
                    pointBorderWidth: 2,
                    pointRadius: chronological.length > 25 ? 3 : 5,
                    pointHoverRadius: 8,
                    pointHoverBackgroundColor: '#ffffff',
                    pointHoverBorderColor: '#06b6d4',
                    borderRadius: chartType === 'bar' ? 6 : 0
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                animation: {
                    duration: 700,
                    easing: 'easeOutQuart'
                },
                interaction: {
                    mode: 'index',
                    intersect: false
                },
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        backgroundColor: tooltipBg,
                        titleColor: tooltipText,
                        bodyColor: textColor,
                        borderColor: 'rgba(168, 85, 247, 0.5)',
                        borderWidth: 1,
                        padding: 12,
                        boxPadding: 6,
                        usePointStyle: true,
                        callbacks: {
                            title: function(tooltipItems) {
                                const idx = tooltipItems[0].dataIndex;
                                const item = chronological[idx];
                                return item ? (item.pdf_name || `Quiz Attempt #${idx + 1}`) : 'Quiz Attempt';
                            },
                            label: function(context) {
                                const idx = context.dataIndex;
                                const item = chronological[idx];
                                const diff = item && item.difficulty ? ` · ${String(item.difficulty).toUpperCase()}` : '';
                                return `Score: ${item.score}/${item.total} (${item.percentage}%)${diff}`;
                            },
                            afterLabel: function(context) {
                                const idx = context.dataIndex;
                                const item = chronological[idx];
                                return item && item.created_at ? `Date: ${item.created_at}` : '';
                            }
                        }
                    }
                },
                scales: {
                    x: {
                        grid: {
                            color: gridColor,
                            drawBorder: false
                        },
                        ticks: {
                            color: textColor,
                            font: { family: "'Plus Jakarta Sans', sans-serif", size: 11 },
                            maxRotation: 45
                        }
                    },
                    y: {
                        min: 0,
                        max: 100,
                        grid: {
                            color: gridColor,
                            drawBorder: false
                        },
                        ticks: {
                            color: textColor,
                            font: { family: "'Plus Jakarta Sans', sans-serif", size: 11 },
                            stepSize: 20,
                            callback: function(val) {
                                return val + '%';
                            }
                        }
                    }
                }
            }
        });
    }

    // Load and Render Progress Data from SQLite & Backend.
    // Uses the unified /quiz/progress endpoint so stats AND history arrive in ONE atomic response.
    // Falls back gracefully if needed, ensuring stats and history can never get out of sync.
    async function loadAndRenderProgressData() {
        let historyItems = Array.isArray(cachedQuizHistory) ? cachedQuizHistory : [];
        let stats = null;
        let progressErr = null;

        try {
            // Primary: Unified endpoint providing BOTH stats and history in a single atomic DB query
            const res = await fetchJsonWithRetry('/quiz/progress', 'loading quiz progress', 1);
            if (res && res.success) {
                if (res.stats) stats = res.stats;
                if (Array.isArray(res.history)) {
                    historyItems = res.history;
                    cachedQuizHistory = historyItems;
                }
            } else {
                throw new Error((res && res.error) || 'Unsuccessful progress response');
            }
        } catch (err) {
            console.warn('Unified progress fetch failed, trying fallbacks:', err);
            progressErr = (err && err.message) || 'unknown network error';

            // Fallback 1: Try /quiz/stats
            try {
                const statsRes = await fetchJsonWithRetry('/quiz/stats', 'loading quiz statistics', 1);
                if (statsRes && statsRes.success) {
                    if (statsRes.stats) stats = statsRes.stats;
                    if (Array.isArray(statsRes.history)) {
                        historyItems = statsRes.history;
                        cachedQuizHistory = historyItems;
                    }
                }
            } catch (sErr) {
                console.error('Fallback /quiz/stats failed:', sErr);
            }

            // Fallback 2: Try /quiz/history if history not yet obtained
            if (!historyItems || historyItems.length === 0) {
                try {
                    const histRes = await fetchJsonWithRetry('/quiz/history', 'loading quiz history', 1);
                    if (histRes && histRes.success && Array.isArray(histRes.history)) {
                        historyItems = histRes.history;
                        cachedQuizHistory = historyItems;
                    }
                } catch (hErr) {
                    console.error('Fallback /quiz/history failed:', hErr);
                }
            }
        }

        if (!stats) {
            // Client-side fallback calculation if /quiz/stats is unavailable
            const count = historyItems.length;
            const totalQ = historyItems.reduce((acc, r) => acc + (parseInt(r.total, 10) || 10), 0);
            const totalC = historyItems.reduce((acc, r) => acc + (parseInt(r.score, 10) || 0), 0);
            const avg = count > 0 ? (historyItems.reduce((acc, r) => acc + (parseFloat(r.percentage) || 0), 0) / count) : 0;
            const bestRow = count > 0 ? historyItems.reduce((best, r) => (parseFloat(r.percentage) > parseFloat(best.percentage) ? r : best), historyItems[0]) : null;
            stats = {
                total_quizzes: count,
                average_score: avg,
                best_score: bestRow ? `${bestRow.percentage}% (${bestRow.score}/${bestRow.total})` : '0%',
                total_questions: totalQ,
                total_correct: totalC,
                overall_accuracy: totalQ > 0 ? (totalC / totalQ) * 100 : 0
            };
            if (progressErr && count === 0) {
                console.warn('Showing zeroed stats because both stats and history failed to load.');
            }
        }

        try {
            updateRankBanner(stats);
        } catch (err) {
            console.error('Failed to render rank banner:', err);
        }
        try {
            updateStatsCards(stats, historyItems);
        } catch (err) {
            console.error('Failed to render stats cards:', err);
        }
        try {
            renderScoreTrendChart(historyItems, currentChartType, progressErr);
        } catch (err) {
            console.error('Failed to render score trend chart:', err);
            if (chartEmptyState) {
                setPanelMessage(chartEmptyState, '⚠️', null, 'Chart failed to render. Reopen My Progress to retry.');
                chartEmptyState.classList.remove('hidden');
            }
            if (scoreTrendChartCanvas) scoreTrendChartCanvas.classList.add('hidden');
        }
        try {
            renderQuizHistoryTable(historyItems, progressErr);
        } catch (err) {
            console.error('Failed to render quiz history table:', err);
        }
        try {
            syncQuizHistoryDates(historyItems);
            updateAchievements(stats, historyItems);
        } catch (err) {
            console.error('Failed to update achievements or sync streak dates:', err);
        }

        // Render any LaTeX math notation present in the history or stats
        try {
            renderMath(progressSection);
        } catch (err) {
            console.error('Failed to render math in progress section:', err);
        }
    }

    // Open Progress Dashboard View
    function openProgressDashboard() {
        if (!quizSection.classList.contains('hidden')) {
            previousViewBeforeProgress = 'quiz';
        } else if (!resultsSection.classList.contains('hidden')) {
            previousViewBeforeProgress = 'results';
        } else {
            previousViewBeforeProgress = 'upload';
        }

        uploadSection.classList.add('hidden');
        resultsSection.classList.add('hidden');
        quizSection.classList.add('hidden');
        loadingSection.classList.add('hidden');
        progressSection.classList.remove('hidden');

        document.body.classList.add('progress-page-active');
        if (myProgressBtn) myProgressBtn.classList.add('active');

        loadAndRenderProgressData();
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }

    // Close Progress Dashboard View & Return to Previous Screen
    function closeProgressDashboard() {
        progressSection.classList.add('hidden');
        document.body.classList.remove('progress-page-active');
        if (myProgressBtn) myProgressBtn.classList.remove('active');

        if (previousViewBeforeProgress === 'results' && summariesData) {
            resultsSection.classList.remove('hidden');
        } else if (previousViewBeforeProgress === 'quiz' && quizQuestions.length > 0) {
            quizSection.classList.remove('hidden');
        } else {
            uploadSection.classList.remove('hidden');
        }
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }

    // Event Listeners for Progress Dashboard
    if (myProgressBtn) {
        myProgressBtn.addEventListener('click', openProgressDashboard);
    }
    if (quizViewProgressBtn) {
        quizViewProgressBtn.addEventListener('click', openProgressDashboard);
    }
    if (backFromProgressBtn) {
        backFromProgressBtn.addEventListener('click', closeProgressDashboard);
    }
    if (progressQuickQuizBtn) {
        progressQuickQuizBtn.addEventListener('click', () => {
            closeProgressDashboard();
            if (selectedFile) {
                openQuizConfigModal();
            } else {
                // Focus drop zone to pick a file
                dropZone.classList.remove('pulse-highlight');
                void dropZone.offsetWidth;
                dropZone.classList.add('pulse-highlight');
                setTimeout(() => dropZone.classList.remove('pulse-highlight'), 1200);
            }
        });
    }
    if (historyStartQuizBtn) {
        historyStartQuizBtn.addEventListener('click', () => {
            closeProgressDashboard();
            if (selectedFile) {
                openQuizConfigModal();
            } else {
                dropZone.classList.remove('pulse-highlight');
                void dropZone.offsetWidth;
                dropZone.classList.add('pulse-highlight');
                setTimeout(() => dropZone.classList.remove('pulse-highlight'), 1200);
            }
        });
    }

    // Chart Type Toggles (Line vs Bar)
    if (chartTypeLineBtn) {
        chartTypeLineBtn.addEventListener('click', () => {
            currentChartType = 'line';
            chartTypeLineBtn.classList.add('active');
            if (chartTypeBarBtn) chartTypeBarBtn.classList.remove('active');
            renderScoreTrendChart(cachedQuizHistory, 'line');
        });
    }
    if (chartTypeBarBtn) {
        chartTypeBarBtn.addEventListener('click', () => {
            currentChartType = 'bar';
            chartTypeBarBtn.classList.add('active');
            if (chartTypeLineBtn) chartTypeLineBtn.classList.remove('active');
            renderScoreTrendChart(cachedQuizHistory, 'bar');
        });
    }

    // ========================================================
    // RESTART PROGRESS DATA & MODAL HANDLERS
    // ========================================================
    function openRestartModal() {
        if (restartConfirmModal) {
            restartConfirmModal.classList.remove('hidden');
        }
    }

    function closeRestartModal() {
        if (restartConfirmModal) {
            restartConfirmModal.classList.add('hidden');
        }
    }

    function showResetSuccessBanner(msg) {
        if (!progressResetAlert) return;
        const msgEl = progressResetAlert.querySelector('.alert-msg');
        if (msgEl && msg) {
            msgEl.textContent = msg;
        }
        progressResetAlert.classList.remove('hidden');
        if (resetAlertTimeout) {
            clearTimeout(resetAlertTimeout);
        }
        resetAlertTimeout = setTimeout(() => {
            progressResetAlert.classList.add('hidden');
        }, 6000);
    }

    async function handleRestartProgress() {
        if (!confirmRestartBtn) return;
        const origContent = confirmRestartBtn.innerHTML;
        try {
            confirmRestartBtn.disabled = true;
            confirmRestartBtn.innerHTML = '<span class="btn-icon">⏳</span><span class="btn-text">Restarting...</span>';

            const res = await fetch('/quiz/reset', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                }
            });

            const data = await safeParseJsonResponse(res, 'restarting progress');
            closeRestartModal();
            showResetSuccessBanner(data.message || 'Progress data has been restarted! You can now record fresh quiz attempts from starting.');
            // Instantly re-fetch and render empty stats & clean dashboard
            await loadAndRenderProgressData();
        } catch (err) {
            console.error('Error resetting quiz progress:', err);
            alert(err.message || 'A network error occurred while restarting progress. Please try again.');
        } finally {
            confirmRestartBtn.disabled = false;
            confirmRestartBtn.innerHTML = origContent;
        }
    }

    if (restartProgressBtn) {
        restartProgressBtn.addEventListener('click', openRestartModal);
    }
    if (closeRestartModalBtn) {
        closeRestartModalBtn.addEventListener('click', closeRestartModal);
    }
    if (cancelRestartModalBtn) {
        cancelRestartModalBtn.addEventListener('click', closeRestartModal);
    }
    if (restartModalBackdrop) {
        restartModalBackdrop.addEventListener('click', closeRestartModal);
    }
    if (confirmRestartBtn) {
        confirmRestartBtn.addEventListener('click', handleRestartProgress);
    }
    if (dismissResetAlertBtn && progressResetAlert) {
        dismissResetAlertBtn.addEventListener('click', () => {
            progressResetAlert.classList.add('hidden');
        });
    }

    // Close modals on Escape key
    window.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
            if (streakCalendarModal && !streakCalendarModal.classList.contains('hidden')) {
                closeStreakCalendarModal();
            } else if (flashcardsModal && !flashcardsModal.classList.contains('hidden')) {
                closeFlashcardsModal();
            } else if (cheatSheetModal && !cheatSheetModal.classList.contains('hidden')) {
                closeCheatSheetModal();
            } else if (wordHelpModal && !wordHelpModal.classList.contains('hidden')) {
                closeWordHelpModal();
            } else if (restartConfirmModal && !restartConfirmModal.classList.contains('hidden')) {
                closeRestartModal();
            } else if (quizConfigModal && !quizConfigModal.classList.contains('hidden')) {
                closeQuizConfigModal();
            }
        }
    });

    // ========================================================
    // PHASE 4: WORD HELP QUICK TERM EXPLAINER LOGIC
    // ========================================================

    function showWordHelpAlert(msg, isDanger = false) {
        if (!wordHelpAlert || !wordHelpAlertMsg) return;
        wordHelpAlertMsg.textContent = msg;
        if (isDanger) {
            wordHelpAlert.classList.add('danger');
        } else {
            wordHelpAlert.classList.remove('danger');
        }
        wordHelpAlert.classList.remove('hidden');
    }

    function hideWordHelpAlert() {
        if (!wordHelpAlert) return;
        wordHelpAlert.classList.add('hidden');
    }

    function displayWordHelpResult(term, explanation, isNotFound) {
        if (!wordHelpResult || !wordHelpAnswerBody || !wordHelpResultTerm) return;
        wordHelpResultTerm.textContent = term;

        if (isNotFound) {
            wordHelpResult.classList.add('not-found');
        } else {
            wordHelpResult.classList.remove('not-found');
        }

        // Format markdown if marked is loaded, otherwise sanitize and format
        let formattedHtml = '';
        if (typeof marked !== 'undefined' && typeof marked.parse === 'function') {
            formattedHtml = marked.parse(explanation);
        } else {
            const escaped = explanation
                .replace(/&/g, '&amp;')
                .replace(/</g, '&lt;')
                .replace(/>/g, '&gt;');
            formattedHtml = `<p>${escaped.replace(/\n/g, '<br>')}</p>`;
        }

        wordHelpAnswerBody.innerHTML = formattedHtml;

        // Run KaTeX auto-render on the answer card
        renderMath(wordHelpAnswerBody);

        wordHelpResult.classList.remove('hidden');
        wordHelpResult.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }

    async function handleWordHelp(e) {
        if (e) e.preventDefault();
        const term = wordHelpInput ? wordHelpInput.value.trim() : '';

        // If no PDF is uploaded yet, show 'Please upload a PDF first'
        if (!selectedFile) {
            showWordHelpAlert('Please upload a PDF first');
            return;
        }

        if (!term) {
            showWordHelpAlert('Please enter a word or concept from your PDF to explain');
            if (wordHelpInput) wordHelpInput.focus();
            return;
        }

        hideWordHelpAlert();
        if (wordHelpResult) wordHelpResult.classList.add('hidden');
        if (wordHelpLoading) wordHelpLoading.classList.remove('hidden');

        if (wordHelpSubmitBtn) wordHelpSubmitBtn.disabled = true;
        if (wordHelpInput) wordHelpInput.disabled = true;

        const formData = new FormData();
        formData.append('pdf', selectedFile);
        formData.append('term', term);

        try {
            const response = await fetch('/word-help', {
                method: 'POST',
                body: formData
            });

            const data = await safeParseJsonResponse(response, 'explaining term');

            displayWordHelpResult(data.term, data.explanation, data.not_found);

        } catch (err) {
            console.error('Word Help error:', err);
            showWordHelpAlert(err.message || 'An error occurred while fetching explanation.', true);
        } finally {
            if (wordHelpLoading) wordHelpLoading.classList.add('hidden');
            if (wordHelpSubmitBtn) wordHelpSubmitBtn.disabled = false;
            if (wordHelpInput) {
                wordHelpInput.disabled = false;
                wordHelpInput.focus();
            }
        }
    }

    if (wordHelpInput) {
        wordHelpInput.addEventListener('input', () => {
            hideWordHelpAlert();
            if (wordHelpClearBtn) {
                if (wordHelpInput.value.trim().length > 0) {
                    wordHelpClearBtn.classList.remove('hidden');
                } else {
                    wordHelpClearBtn.classList.add('hidden');
                }
            }
        });

        wordHelpInput.addEventListener('keydown', (e) => {
            if (e.key === 'Enter') {
                e.preventDefault();
                handleWordHelp(e);
            }
        });
    }

    if (wordHelpClearBtn && wordHelpInput) {
        wordHelpClearBtn.addEventListener('click', () => {
            wordHelpInput.value = '';
            wordHelpClearBtn.classList.add('hidden');
            hideWordHelpAlert();
            wordHelpInput.focus();
        });
    }

    if (wordHelpForm) {
        wordHelpForm.addEventListener('submit', handleWordHelp);
    }

    if (wordHelpSubmitBtn) {
        wordHelpSubmitBtn.addEventListener('click', handleWordHelp);
    }

    if (closeWordHelpResultBtn && wordHelpResult) {
        closeWordHelpResultBtn.addEventListener('click', () => {
            wordHelpResult.classList.add('hidden');
        });
    }

    // Modal open/close handlers
    function openWordHelpModal() {
        if (wordHelpTargetFileName) {
            wordHelpTargetFileName.textContent = selectedFile ? selectedFile.name : 'No PDF selected yet';
        }
        if (!selectedFile) {
            showWordHelpAlert('Please upload a PDF first');
        } else {
            hideWordHelpAlert();
        }
        if (wordHelpModal) {
            wordHelpModal.classList.remove('hidden');
        }
        if (wordHelpInput) {
            setTimeout(() => {
                wordHelpInput.focus();
            }, 120);
        }
    }

    function closeWordHelpModal() {
        if (wordHelpModal) {
            wordHelpModal.classList.add('hidden');
        }
    }

    if (wordHelpTriggerBtn) {
        wordHelpTriggerBtn.addEventListener('click', openWordHelpModal);
    }
    if (resultsWordHelpBtn) {
        resultsWordHelpBtn.addEventListener('click', openWordHelpModal);
    }
    if (closeWordHelpModalBtn) {
        closeWordHelpModalBtn.addEventListener('click', closeWordHelpModal);
    }
    if (cancelWordHelpModalBtn) {
        cancelWordHelpModalBtn.addEventListener('click', closeWordHelpModal);
    }
    if (wordHelpModalBackdrop) {
        wordHelpModalBackdrop.addEventListener('click', closeWordHelpModal);
    }

    // ========================================================
    // FEATURE ADDON 1: DAILY STUDY STREAK & DOTTED CALENDAR ENGINE
    // ========================================================
    const STREAK_STORAGE_KEY = 'studysnap_streak_data_v1';

    function getStreakData() {
        try {
            const raw = localStorage.getItem(STREAK_STORAGE_KEY);
            if (raw) {
                const parsed = JSON.parse(raw);
                if (!Array.isArray(parsed.studyDates)) {
                    parsed.studyDates = parsed.lastStudyDate ? [parsed.lastStudyDate] : [];
                }
                return parsed;
            }
        } catch (e) {
            console.warn('Failed to parse streak storage:', e);
        }
        return { lastStudyDate: null, currentStreak: 0, bestStreak: 0, studyDates: [] };
    }

    function saveStreakData(data) {
        try {
            localStorage.setItem(STREAK_STORAGE_KEY, JSON.stringify(data));
        } catch (e) {
            console.warn('Failed to save streak storage:', e);
        }
    }

    function getTodayDateString() {
        const now = new Date();
        const y = now.getFullYear();
        const m = String(now.getMonth() + 1).padStart(2, '0');
        const d = String(now.getDate()).padStart(2, '0');
        return `${y}-${m}-${d}`;
    }

    function syncQuizHistoryDates(historyItems) {
        if (!Array.isArray(historyItems) || historyItems.length === 0) return;
        const streakData = getStreakData();
        if (!Array.isArray(streakData.studyDates)) streakData.studyDates = [];
        let added = false;
        for (const item of historyItems) {
            if (item.created_at) {
                try {
                    const d = new Date(item.created_at);
                    if (!isNaN(d.getTime())) {
                        const y = d.getFullYear();
                        const m = String(d.getMonth() + 1).padStart(2, '0');
                        const day = String(d.getDate()).padStart(2, '0');
                        const key = `${y}-${m}-${day}`;
                        if (!streakData.studyDates.includes(key)) {
                            streakData.studyDates.push(key);
                            added = true;
                        }
                    }
                } catch (e) {
                    // Ignore date parse
                }
            }
        }
        if (added) {
            saveStreakData(streakData);
        }
    }

    function initStudyStreak() {
        const streakData = getStreakData();
        const today = getTodayDateString();
        let displayStreak = streakData.currentStreak || 0;

        if (streakData.lastStudyDate) {
            const last = new Date(streakData.lastStudyDate);
            const curr = new Date(today);
            const diffDays = Math.round((curr - last) / (1000 * 60 * 60 * 24));

            if (diffDays > 1) {
                // Streak broken if gap is more than 1 day
                displayStreak = 0;
                streakData.currentStreak = 0;
                saveStreakData(streakData);
            }
        }

        if (streakCountVal) {
            streakCountVal.textContent = `${displayStreak} ${displayStreak === 1 ? 'Day' : 'Days'}`;
        }
        return displayStreak;
    }

    function recordStudyActivity() {
        const streakData = getStreakData();
        const today = getTodayDateString();

        if (!Array.isArray(streakData.studyDates)) {
            streakData.studyDates = [];
        }
        if (!streakData.studyDates.includes(today)) {
            streakData.studyDates.push(today);
        }

        if (streakData.lastStudyDate === today) {
            // Already active today
            saveStreakData(streakData);
            return streakData.currentStreak;
        }

        if (!streakData.lastStudyDate) {
            streakData.currentStreak = 1;
        } else {
            const last = new Date(streakData.lastStudyDate);
            const curr = new Date(today);
            const diffDays = Math.round((curr - last) / (1000 * 60 * 60 * 24));

            if (diffDays === 1) {
                streakData.currentStreak += 1;
            } else {
                streakData.currentStreak = 1;
            }
        }

        streakData.lastStudyDate = today;
        streakData.bestStreak = Math.max(streakData.bestStreak || 0, streakData.currentStreak);
        saveStreakData(streakData);

        if (streakCountVal) {
            streakCountVal.textContent = `${streakData.currentStreak} ${streakData.currentStreak === 1 ? 'Day' : 'Days'}`;
        }
        return streakData.currentStreak;
    }

    // ========================================================
    // DOTTED STREAK ACTIVITY CALENDAR RENDERER
    // ========================================================
    let currentCalYear = new Date().getFullYear();
    let currentCalMonth = new Date().getMonth();

    function renderStreakCalendarGrid() {
        const monthNames = [
            'January', 'February', 'March', 'April', 'May', 'June',
            'July', 'August', 'September', 'October', 'November', 'December'
        ];
        if (streakCalMonthTitle) {
            streakCalMonthTitle.textContent = `${monthNames[currentCalMonth]} ${currentCalYear}`;
        }

        const firstDayIndex = new Date(currentCalYear, currentCalMonth, 1).getDay();
        const daysInMonth = new Date(currentCalYear, currentCalMonth + 1, 0).getDate();
        const daysInPrevMonth = new Date(currentCalYear, currentCalMonth, 0).getDate();

        const streakData = getStreakData();
        const studySet = new Set(streakData.studyDates || []);
        if (streakData.lastStudyDate) studySet.add(streakData.lastStudyDate);

        const todayStr = getTodayDateString();
        let monthWorkedCount = 0;

        let html = '';

        // Previous month trailing days
        for (let i = firstDayIndex - 1; i >= 0; i--) {
            const d = daysInPrevMonth - i;
            html += `
                <div class="streak-day-cell other-month">
                    <span class="day-number">${d}</span>
                </div>
            `;
        }

        // Current month days with glowing numbers for worked days
        for (let day = 1; day <= daysInMonth; day++) {
            const mStr = String(currentCalMonth + 1).padStart(2, '0');
            const dStr = String(day).padStart(2, '0');
            const dateKey = `${currentCalYear}-${mStr}-${dStr}`;

            const isWorked = studySet.has(dateKey);
            const isToday = (dateKey === todayStr);

            if (isWorked) monthWorkedCount++;

            const cellClasses = ['streak-day-cell'];
            if (isWorked) cellClasses.push('worked');
            else cellClasses.push('empty');
            if (isToday) cellClasses.push('is-today');

            const tooltip = isWorked
                ? `🔥 Active Study Day (${dateKey})`
                : (isToday ? `⭐ Today (${dateKey})` : `⚪ Rest Day (${dateKey})`);

            html += `
                <div class="${cellClasses.join(' ')}" title="${tooltip}" data-date="${dateKey}">
                    <span class="day-number">${day}</span>
                </div>
            `;
        }

        // Next month trailing days to complete 7-col grid
        const totalRendered = firstDayIndex + daysInMonth;
        const remaining = (7 - (totalRendered % 7)) % 7;
        for (let day = 1; day <= remaining; day++) {
            html += `
                <div class="streak-day-cell other-month">
                    <span class="day-number">${day}</span>
                </div>
            `;
        }

        if (streakDaysGrid) {
            streakDaysGrid.innerHTML = html;
        }

        // Update hero banner counts
        if (streakModalHeroCount) {
            streakModalHeroCount.textContent = streakData.currentStreak || 0;
        }
        if (streakModalBestCount) {
            streakModalBestCount.textContent = `${streakData.bestStreak || streakData.currentStreak || 0} Days`;
        }
        if (streakModalTotalWorked) {
            streakModalTotalWorked.textContent = `${studySet.size} Days`;
        }
        if (streakModalMonthWorked) {
            streakModalMonthWorked.textContent = `${monthWorkedCount} Days`;
        }
        if (streakModalHeroStatus) {
            if (studySet.has(todayStr)) {
                streakModalHeroStatus.textContent = "🔥 You studied today! Streak is safely preserved.";
            } else {
                streakModalHeroStatus.textContent = "⚡ Study or take a quiz today to keep your streak glowing!";
            }
        }
    }

    function openStreakCalendarModal() {
        if (cachedQuizHistory && cachedQuizHistory.length > 0) {
            syncQuizHistoryDates(cachedQuizHistory);
        }
        currentCalYear = new Date().getFullYear();
        currentCalMonth = new Date().getMonth();
        renderStreakCalendarGrid();
        if (streakCalendarModal) {
            streakCalendarModal.classList.remove('hidden');
        }
    }

    function closeStreakCalendarModal() {
        if (streakCalendarModal) {
            streakCalendarModal.classList.add('hidden');
        }
    }

    // ========================================================
    // FEATURE ADDON 2: GAMIFIED ACHIEVEMENT MEDALS ENGINE
    // ========================================================
    function updateAchievements(stats, historyItems) {
        if (!achievementsCard) return;

        const totalQuizzes = stats ? (parseInt(stats.total_quizzes, 10) || 0) : 0;
        const totalQuestions = stats ? (parseInt(stats.total_questions, 10) || 0) : 0;
        const avgScore = stats ? (parseFloat(stats.average_score) || 0) : 0;
        const streak = getStreakData().currentStreak || 0;

        let hasHighQuiz = false;
        let hasFlawlessQuiz = false;

        if (Array.isArray(historyItems)) {
            for (const h of historyItems) {
                const pct = parseFloat(h.percentage) || 0;
                if (pct >= 80) hasHighQuiz = true;
                if (pct >= 100) hasFlawlessQuiz = true;
            }
        }

        const achievementsList = [
            { el: achFirstQuiz, unlocked: totalQuizzes >= 1 },
            { el: achSharpScholar, unlocked: hasHighQuiz },
            { el: achTierAscendant, unlocked: avgScore >= 40 },
            { el: achDedicatedMind, unlocked: totalQuestions >= 20 },
            { el: achPerfectionist, unlocked: hasFlawlessQuiz },
            { el: achStreakMaster, unlocked: streak >= 2 }
        ];

        let unlockedCount = 0;
        achievementsList.forEach(item => {
            if (!item.el) return;
            const statusEl = item.el.querySelector('.medal-status');
            if (item.unlocked) {
                unlockedCount++;
                item.el.classList.add('unlocked');
                if (statusEl) {
                    statusEl.textContent = 'Unlocked 🏆';
                    statusEl.className = 'medal-status unlocked';
                }
            } else {
                item.el.classList.remove('unlocked');
                if (statusEl) {
                    statusEl.textContent = 'Locked';
                    statusEl.className = 'medal-status locked';
                }
            }
        });

        if (achievementsUnlockedBadge) {
            achievementsUnlockedBadge.textContent = `${unlockedCount} / 6 Unlocked`;
        }
    }

    // ========================================================
    // FEATURE ADDON 3: 3D FLIP CONCEPT FLASHCARDS STUDIO
    // ========================================================
    let flashcardDeck = [];
    let currentCardIndex = 0;
    const masteredCardIndices = new Set();

    function extractFlashcardsFromSummary() {
        const cards = [];
        if (!summariesData) {
            return [
                {
                    category: "ACTIVE RECALL 🧠",
                    question: "What is Active Recall and why is it effective?",
                    answer: "Active recall is the practice of stimulating memory retrieval during learning. Testing yourself boosts long-term retention by up to 200% compared to passive rereading."
                },
                {
                    category: "STUDYSNAP AI ⚡",
                    question: "How does StudySnap synthesize documents?",
                    answer: "StudySnap analyzes complex PDFs using advanced AI to generate Easy, Deep, and Fun explanations, customizable quizzes, and automated exam cram cheat sheets."
                },
                {
                    category: "SPACED REPETITION 🔥",
                    question: "How does the daily study streak help learning?",
                    answer: "Reviewing documents and completing quizzes on consecutive days locks in memory curves, keeps your streak alive, and levels up your gamer achievement trophies!"
                }
            ];
        }

        const sourceTexts = [
            summariesData.deep || '',
            summariesData.easy || '',
            summariesData.fun || ''
        ].join('\n\n');

        const lines = sourceTexts.split('\n');

        // Pattern 1: Bold term followed by colon: - **Term**: Explanation
        const termRegex = /^[\s*-•]*\*\*([^*:\n]{2,60})\*\*\s*[:–-]\s*(.+)$/;

        // Pattern 2: Heading 2/3/4
        const headingRegex = /^#{2,4}\s+(.+)$/;

        let currentHeading = null;
        let currentHeadingBody = [];

        for (let i = 0; i < lines.length; i++) {
            const line = lines[i].trim();
            if (!line) continue;

            const termMatch = line.match(termRegex);
            if (termMatch) {
                const term = termMatch[1].trim();
                const explanation = termMatch[2].replace(/[*_]/g, '').trim();
                if (term.length >= 2 && explanation.length >= 10) {
                    cards.push({
                        category: "DEFINITION 🔑",
                        question: `What is ${term}?`,
                        answer: explanation
                    });
                }
                continue;
            }

            const headMatch = line.match(headingRegex);
            if (headMatch) {
                if (currentHeading && currentHeadingBody.length > 0) {
                    const ans = currentHeadingBody.join(' ').replace(/[*_]/g, '').trim();
                    if (ans.length >= 20 && ans.length <= 400) {
                        cards.push({
                            category: "KEY CONCEPT 💡",
                            question: `Explain: ${currentHeading}`,
                            answer: ans
                        });
                    }
                }
                currentHeading = headMatch[1].replace(/[*#]/g, '').trim();
                currentHeadingBody = [];
                continue;
            }

            if (currentHeading && currentHeadingBody.length < 3) {
                if (!line.startsWith('#') && line.length > 15) {
                    currentHeadingBody.push(line.replace(/^[-*•]\s*/, ''));
                }
            }
        }

        if (currentHeading && currentHeadingBody.length > 0) {
            const ans = currentHeadingBody.join(' ').replace(/[*_]/g, '').trim();
            if (ans.length >= 20 && ans.length <= 400) {
                cards.push({
                    category: "KEY CONCEPT 💡",
                    question: `Explain: ${currentHeading}`,
                    answer: ans
                });
            }
        }

        // Extract LaTeX equations (safely bounded)
        let formulaCount = 0;
        const mathMatches = sourceTexts.matchAll(/\$\$([^$]+?)\$\$|\$([^$\n]{2,80})\$/g);
        for (const match of mathMatches) {
            const formula = (match[1] || match[2] || '').trim();
            if (formula.length >= 3 && formula.length <= 80 && !cards.some(c => c.answer.includes(formula))) {
                cards.push({
                    category: "FORMULA ⚡",
                    question: "Identify and formulate this equation:",
                    answer: `$$\n${formula}\n$$`
                });
                formulaCount++;
                if (formulaCount >= 5) break;
            }
        }

        // De-duplicate by question
        const seen = new Set();
        const uniqueCards = [];
        for (const card of cards) {
            const key = card.question.toLowerCase().trim();
            if (!seen.has(key)) {
                seen.add(key);
                uniqueCards.push(card);
            }
        }

        // Fallback if few cards extracted
        if (uniqueCards.length < 4) {
            const paragraphs = sourceTexts.split(/\n\s*\n/);
            for (const p of paragraphs) {
                const clean = p.replace(/[*#]/g, '').trim();
                if (clean.length > 40 && clean.length < 350 && !clean.startsWith('-')) {
                    const firstPeriod = clean.indexOf('. ');
                    if (firstPeriod > 15 && firstPeriod < 120) {
                        const qPart = clean.slice(0, firstPeriod + 1);
                        const aPart = clean.slice(firstPeriod + 2);
                        if (aPart.length > 20) {
                            uniqueCards.push({
                                category: "TAKEAWAY 🎯",
                                question: `Core Takeaway: ${qPart}`,
                                answer: aPart
                            });
                        }
                    }
                }
                if (uniqueCards.length >= 8) break;
            }
        }

        return uniqueCards.length > 0 ? uniqueCards : [
            {
                category: "KEY CONCEPT 💡",
                question: "Core Document Overview",
                answer: summariesData.easy ? summariesData.easy.slice(0, 240) + '...' : "Review the main summary sections for key ideas."
            }
        ];
    }

    function renderCurrentFlashcard() {
        if (!flashcardDeck || flashcardDeck.length === 0) return;
        if (currentCardIndex < 0) currentCardIndex = 0;
        if (currentCardIndex >= flashcardDeck.length) currentCardIndex = flashcardDeck.length - 1;

        const card = flashcardDeck[currentCardIndex];
        if (flashcardCard) {
            flashcardCard.classList.remove('flipped');
        }

        if (cardQuestionText) {
            cardQuestionText.textContent = card.question;
        }
        if (cardAnswerText) {
            if (typeof marked !== 'undefined' && typeof marked.parse === 'function' && (card.answer.includes('*') || card.answer.includes('\n'))) {
                cardAnswerText.innerHTML = marked.parse(card.answer);
            } else {
                cardAnswerText.textContent = card.answer;
            }
        }
        if (cardCategoryBadge) {
            cardCategoryBadge.textContent = card.category || 'KEY CONCEPT';
        }

        if (flashcardProgress) {
            flashcardProgress.textContent = `Card ${currentCardIndex + 1} of ${flashcardDeck.length}`;
        }
        if (flashcardsMeterFill) {
            const pct = Math.round(((currentCardIndex + 1) / flashcardDeck.length) * 100);
            flashcardsMeterFill.style.width = `${pct}%`;
        }
        if (flashcardMasteredCount) {
            flashcardMasteredCount.textContent = `${masteredCardIndices.size} Mastered`;
        }

        if (flashcardPrevBtn) {
            flashcardPrevBtn.disabled = (currentCardIndex === 0);
        }
        if (flashcardNextBtn) {
            flashcardNextBtn.disabled = (currentCardIndex === flashcardDeck.length - 1);
        }

        if (flashcardCard) {
            renderMath(flashcardCard);
        }
    }

    function toggleFlashcardFlip() {
        if (flashcardCard) {
            flashcardCard.classList.toggle('flipped');
        }
    }

    function markCardMastered() {
        masteredCardIndices.add(currentCardIndex);
        if (currentCardIndex < flashcardDeck.length - 1) {
            currentCardIndex++;
            renderCurrentFlashcard();
        } else {
            renderCurrentFlashcard();
        }
    }

    function markCardReviewAgain() {
        masteredCardIndices.delete(currentCardIndex);
        if (currentCardIndex < flashcardDeck.length - 1) {
            currentCardIndex++;
            renderCurrentFlashcard();
        } else {
            renderCurrentFlashcard();
        }
    }

    function openFlashcardsModal() {
        flashcardDeck = extractFlashcardsFromSummary();
        currentCardIndex = 0;
        masteredCardIndices.clear();

        if (flashcardDocSubtitle) {
            flashcardDocSubtitle.textContent = selectedFile ? selectedFile.name : (resultDocName ? resultDocName.textContent : 'Concept Flashcards');
        }

        renderCurrentFlashcard();
        if (flashcardsModal) {
            flashcardsModal.classList.remove('hidden');
        }
    }

    function closeFlashcardsModal() {
        if (flashcardsModal) {
            flashcardsModal.classList.add('hidden');
        }
        if (flashcardCard) {
            flashcardCard.classList.remove('flipped');
        }
    }

    // ========================================================
    // FEATURE ADDON 4: 1-PAGE EXAM CRAM / CHEAT SHEET GENERATOR
    // ========================================================
    function populateCheatSheetContent() {
        if (!summariesData) {
            if (cheatSheetBigIdeas) {
                cheatSheetBigIdeas.innerHTML = '<ol class="cheat-list"><li>Upload a document and synthesize summaries to generate your customized exam cram sheet.</li><li>StudySnap identifies core principles, math equations, and key vocabulary automatically.</li></ol>';
            }
            if (cheatSheetFormulas) {
                cheatSheetFormulas.innerHTML = '<p class="cheat-empty">Formulas and equations from your document will appear here.</p>';
            }
            if (cheatSheetTerms) {
                cheatSheetTerms.innerHTML = '<p class="cheat-empty">Key defined terms and concepts will appear here.</p>';
            }
            if (cheatSheetTraps) {
                cheatSheetTraps.innerHTML = '<p class="cheat-empty">Common exam pitfalls and distinctions will appear here.</p>';
            }
            return;
        }

        const fullText = [summariesData.deep || '', summariesData.easy || '', summariesData.fun || ''].join('\n\n');
        const lines = fullText.split('\n');

        // 1. Top 5 Must-Knows
        const takeaways = [];
        for (const line of lines) {
            const clean = line.replace(/^[-*•\d.]+\s*/, '').trim();
            if (clean.length > 35 && clean.length < 220 && !clean.startsWith('#')) {
                takeaways.push(clean.replace(/[*_]/g, ''));
                if (takeaways.length >= 5) break;
            }
        }
        if (cheatSheetBigIdeas) {
            if (takeaways.length > 0) {
                cheatSheetBigIdeas.innerHTML = '<ol class="cheat-list">' + takeaways.map(t => `<li>${t}</li>`).join('') + '</ol>';
            } else {
                cheatSheetBigIdeas.innerHTML = '<p class="cheat-empty">Review primary summary for core takeaways.</p>';
            }
        }

        // 2. Formulas & Equations
        const formulas = [];
        const mathRegex = /\$\$([\s\S]+?)\$\$|\$([^\$\n]+?)\$/g;
        let match;
        while ((match = mathRegex.exec(fullText)) !== null) {
            const expr = (match[1] || match[2] || '').trim();
            if (expr.length >= 3 && expr.length <= 120 && !formulas.includes(expr)) {
                formulas.push(expr);
                if (formulas.length >= 4) break;
            }
        }
        if (cheatSheetFormulas) {
            if (formulas.length > 0) {
                cheatSheetFormulas.innerHTML = '<div class="cheat-formula-list">' + formulas.map(f => `<div class="cheat-formula-box">$$${f}$$</div>`).join('') + '</div>';
            } else {
                cheatSheetFormulas.innerHTML = '<p class="cheat-empty">No explicit mathematical formulas detected in this document.</p>';
            }
        }

        // 3. Essential Definitions
        const terms = [];
        const termRegex = /^[\s*-]*\*\*([^*:\n]{3,60})\*\*\s*[:–-]\s*(.+)$/;
        for (const line of lines) {
            const tMatch = line.trim().match(termRegex);
            if (tMatch) {
                const term = tMatch[1].trim();
                const def = tMatch[2].replace(/[*_]/g, '').trim();
                if (term.length >= 3 && def.length >= 10 && !terms.some(x => x.term.toLowerCase() === term.toLowerCase())) {
                    terms.push({ term, def });
                    if (terms.length >= 5) break;
                }
            }
        }
        if (cheatSheetTerms) {
            if (terms.length > 0) {
                cheatSheetTerms.innerHTML = '<ul class="cheat-list">' + terms.map(t => `<li><strong>${t.term}</strong>: ${t.def}</li>`).join('') + '</ul>';
            } else {
                cheatSheetTerms.innerHTML = '<p class="cheat-empty">Key terminology will populate from structured summaries.</p>';
            }
        }

        // 4. Common Traps & Pitfalls
        const traps = [];
        const trapKeywords = ['however', 'unlike', 'contrast', 'caution', 'mistake', 'trap', 'crucial', 'note', 'pitfall', 'warning', 'critical'];
        for (const line of lines) {
            const lower = line.toLowerCase();
            if (trapKeywords.some(kw => lower.includes(kw)) && !line.startsWith('#')) {
                const clean = line.replace(/^[-*•\d.]+\s*/, '').replace(/[*_]/g, '').trim();
                if (clean.length > 30 && clean.length < 240 && !traps.includes(clean)) {
                    traps.push(clean);
                    if (traps.length >= 4) break;
                }
            }
        }
        if (cheatSheetTraps) {
            if (traps.length > 0) {
                cheatSheetTraps.innerHTML = '<ul class="cheat-list">' + traps.map(tr => `<li>⚠️ ${tr}</li>`).join('') + '</ul>';
            } else {
                cheatSheetTraps.innerHTML = '<ul class="cheat-list"><li>Pay close attention to boundary conditions and exceptions.</li><li>Avoid confusing related terminology and check assumptions.</li></ul>';
            }
        }
    }

    function openCheatSheetModal() {
        const docTitle = selectedFile ? selectedFile.name : (resultDocName ? resultDocName.textContent : 'StudySnap Document');
        if (cheatSheetDocTitle) {
            cheatSheetDocTitle.textContent = docTitle;
        }
        if (cheatSheetDocSubtitle) {
            cheatSheetDocSubtitle.textContent = docTitle;
        }
        if (cheatSheetDate) {
            cheatSheetDate.textContent = new Date().toLocaleDateString(undefined, {
                year: 'numeric',
                month: 'long',
                day: 'numeric'
            });
        }

        populateCheatSheetContent();

        if (cheatSheetModal) {
            cheatSheetModal.classList.remove('hidden');
            renderMath(cheatSheetModal);
        }
    }

    function closeCheatSheetModal() {
        if (cheatSheetModal) {
            cheatSheetModal.classList.add('hidden');
        }
    }

    // ========================================================
    // FEATURE ADDON EVENT LISTENERS & SHORTCUTS
    // ========================================================
    if (studyStreakBadge) {
        studyStreakBadge.addEventListener('click', openStreakCalendarModal);
        studyStreakBadge.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                openStreakCalendarModal();
            }
        });
    }
    if (closeStreakCalendarModalBtn) {
        closeStreakCalendarModalBtn.addEventListener('click', closeStreakCalendarModal);
    }
    if (streakCalendarModalBackdrop) {
        streakCalendarModalBackdrop.addEventListener('click', closeStreakCalendarModal);
    }
    if (streakCalPrevMonthBtn) {
        streakCalPrevMonthBtn.addEventListener('click', () => {
            currentCalMonth--;
            if (currentCalMonth < 0) {
                currentCalMonth = 11;
                currentCalYear--;
            }
            renderStreakCalendarGrid();
        });
    }
    if (streakCalNextMonthBtn) {
        streakCalNextMonthBtn.addEventListener('click', () => {
            currentCalMonth++;
            if (currentCalMonth > 11) {
                currentCalMonth = 0;
                currentCalYear++;
            }
            renderStreakCalendarGrid();
        });
    }
    if (streakCalTodayBtn) {
        streakCalTodayBtn.addEventListener('click', () => {
            currentCalYear = new Date().getFullYear();
            currentCalMonth = new Date().getMonth();
            renderStreakCalendarGrid();
        });
    }
    if (resultsFlashcardsBtn) {
        resultsFlashcardsBtn.addEventListener('click', openFlashcardsModal);
    }
    if (resultsCheatSheetBtn) {
        resultsCheatSheetBtn.addEventListener('click', openCheatSheetModal);
    }
    if (closeFlashcardsModalBtn) {
        closeFlashcardsModalBtn.addEventListener('click', closeFlashcardsModal);
    }
    if (flashcardsModalBackdrop) {
        flashcardsModalBackdrop.addEventListener('click', closeFlashcardsModal);
    }
    if (closeCheatSheetModalBtn) {
        closeCheatSheetModalBtn.addEventListener('click', closeCheatSheetModal);
    }
    if (cheatSheetModalBackdrop) {
        cheatSheetModalBackdrop.addEventListener('click', closeCheatSheetModal);
    }

    if (printCheatSheetBtn) {
        printCheatSheetBtn.addEventListener('click', () => {
            window.print();
        });
    }

    if (flashcardCard) {
        flashcardCard.addEventListener('click', toggleFlashcardFlip);

        // Touch swipe gestures for mobile phones (Swipe left: Next, Swipe right: Prev)
        let touchStartX = 0;
        let touchStartY = 0;
        let isTouchSwipe = false;

        flashcardCard.addEventListener('touchstart', (e) => {
            if (!e.changedTouches || e.changedTouches.length === 0) return;
            touchStartX = e.changedTouches[0].clientX;
            touchStartY = e.changedTouches[0].clientY;
            isTouchSwipe = true;
        }, { passive: true });

        flashcardCard.addEventListener('touchend', (e) => {
            if (!isTouchSwipe || !e.changedTouches || e.changedTouches.length === 0) return;
            isTouchSwipe = false;
            const touchEndX = e.changedTouches[0].clientX;
            const touchEndY = e.changedTouches[0].clientY;
            const diffX = touchEndX - touchStartX;
            const diffY = touchEndY - touchStartY;

            // Swipe threshold of 45px, dominant over vertical scrolling
            if (Math.abs(diffX) > 45 && Math.abs(diffX) > Math.abs(diffY) * 1.3) {
                if (diffX < 0) {
                    // Swiped Left -> Next Card
                    if (currentCardIndex < flashcardDeck.length - 1) {
                        currentCardIndex++;
                        renderCurrentFlashcard();
                    }
                } else {
                    // Swiped Right -> Previous Card
                    if (currentCardIndex > 0) {
                        currentCardIndex--;
                        renderCurrentFlashcard();
                    }
                }
            }
        }, { passive: true });
    }
    if (flashcardFlipBtn) {
        flashcardFlipBtn.addEventListener('click', toggleFlashcardFlip);
    }
    if (flashcardPrevBtn) {
        flashcardPrevBtn.addEventListener('click', () => {
            if (currentCardIndex > 0) {
                currentCardIndex--;
                renderCurrentFlashcard();
            }
        });
    }
    if (flashcardNextBtn) {
        flashcardNextBtn.addEventListener('click', () => {
            if (currentCardIndex < flashcardDeck.length - 1) {
                currentCardIndex++;
                renderCurrentFlashcard();
            }
        });
    }
    if (cardReviewAgainBtn) {
        cardReviewAgainBtn.addEventListener('click', markCardReviewAgain);
    }
    if (cardMasteredBtn) {
        cardMasteredBtn.addEventListener('click', markCardMastered);
    }

    // Keyboard navigation for 3D Flashcards
    window.addEventListener('keydown', (e) => {
        if (!flashcardsModal || flashcardsModal.classList.contains('hidden')) return;

        if (e.code === 'Space') {
            e.preventDefault();
            toggleFlashcardFlip();
        } else if (e.key === 'ArrowRight') {
            e.preventDefault();
            if (currentCardIndex < flashcardDeck.length - 1) {
                currentCardIndex++;
                renderCurrentFlashcard();
            }
        } else if (e.key === 'ArrowLeft') {
            e.preventDefault();
            if (currentCardIndex > 0) {
                currentCardIndex--;
                renderCurrentFlashcard();
            }
        } else if (e.key === '1') {
            e.preventDefault();
            markCardReviewAgain();
        } else if (e.key === '2') {
            e.preventDefault();
            markCardMastered();
        }
    });

    // ========================================================
    // SMALL CIRCULAR FLEXIBLE BLACK CURSOR (UNIFORM & STABLE)
    // ========================================================
    function initBouncyCursor() {
        const bouncyCursor = document.getElementById('bouncyCursor');
        const cursorBall = document.getElementById('cursorBall');

        if (!bouncyCursor || !cursorBall) return;

        // Only activate on devices with fine pointer (mouse / trackpad)
        if (window.matchMedia && !window.matchMedia('(pointer: fine)').matches) {
            return;
        }

        let mouseX = window.innerWidth / 2;
        let mouseY = window.innerHeight / 2;
        let ballX = mouseX;
        let ballY = mouseY;
        let vx = 0;
        let vy = 0;
        let currentAngle = 0;
        let currentStretch = 0;
        let isClicking = false;
        let hasInitialized = false;

        window.addEventListener('mousemove', (e) => {
            mouseX = e.clientX;
            mouseY = e.clientY;

            if (!hasInitialized) {
                // First mouse move: snap ball immediately without initial fly-in
                ballX = mouseX;
                ballY = mouseY;
                hasInitialized = true;
                bouncyCursor.classList.add('visible');
            } else {
                bouncyCursor.classList.add('visible');
            }
        });

        // Click effect: subtle tactile response without altering circle identity
        document.addEventListener('mousedown', () => {
            isClicking = true;
        });

        document.addEventListener('mouseup', () => {
            isClicking = false;
        });

        // Window leave / enter
        document.addEventListener('mouseleave', () => {
            bouncyCursor.classList.remove('visible');
        });

        document.addEventListener('mouseenter', () => {
            bouncyCursor.classList.add('visible');
        });

        // Ultra-Flexible Elastic Spring & Fluid Velocity Animation Loop
        // Circle remains the same uniform circle at all times (no changes on hover or selection)
        function animateCursor() {
            if (hasInitialized) {
                // Organic spring physics: elastic trailing with bounce
                const dx = mouseX - ballX;
                const dy = mouseY - ballY;

                vx += dx * 0.22;
                vy += dy * 0.22;
                vx *= 0.72; // friction creates fluid bounce and flexible trailing
                vy *= 0.72;

                ballX += vx;
                ballY += vy;

                // Speed calculation
                const speed = Math.hypot(vx, vy);

                // Very flexible stretch: dynamically elongates smoothly along velocity vector
                const maxStretch = 1.35;
                const targetStretch = Math.min(speed * 0.065, maxStretch);

                // Elastic stretch smoothing creates realistic rubber trailing/recoil
                currentStretch += (targetStretch - currentStretch) * 0.28;

                // Smooth fluid bending around curves and turns
                if (speed > 0.4) {
                    const targetAngle = Math.atan2(vy, vx);
                    let diff = targetAngle - currentAngle;
                    while (diff < -Math.PI) diff += Math.PI * 2;
                    while (diff > Math.PI) diff -= Math.PI * 2;
                    currentAngle += diff * 0.28;
                }

                // Volume-preserving flexible deformation
                let scaleX = 1 + currentStretch;
                let scaleY = 1 / Math.sqrt(1 + currentStretch * 1.15);

                // Circle ball stays identical at all times (no changes on click or selection)
                cursorBall.style.transform = `translate3d(${ballX.toFixed(2)}px, ${ballY.toFixed(2)}px, 0) rotate(${currentAngle.toFixed(4)}rad) scale(${scaleX.toFixed(3)}, ${scaleY.toFixed(3)})`;
            }

            requestAnimationFrame(animateCursor);
        }

        requestAnimationFrame(animateCursor);
    }

    // Initialize custom cursor and study streak
    initBouncyCursor();
    initStudyStreak();

    // Proactively verify environment and API key health on startup
    async function checkHealthStatus() {
        try {
            const res = await fetch('/health');
            if (res.ok) {
                const data = await res.json();
                if (data && data.api_key_configured === false) {
                    showError(
                        `⚠️ Notice: GEMINI_API_KEY is not detected. Please add GEMINI_API_KEY in your ${data.platform === 'vercel' ? 'Vercel' : 'Render'} dashboard under Environment variables and rebuild.`
                    );
                }
            }
        } catch (e) {
            // Non-blocking background health check
        }
    }
    checkHealthStatus();
});
